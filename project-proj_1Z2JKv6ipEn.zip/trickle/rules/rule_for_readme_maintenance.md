When project is updated with significant changes

- Check if README.md needs to be updated with new features, pages, or functionality
- Update README.md structure section if new components or pages are added
- Update README.md functionality section if new features are implemented
- Keep README.md concise and focused on key information
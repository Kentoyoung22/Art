# Guia de Instalação do App Maternia

O Sistema Maternia agora está disponível como Progressive Web App (PWA) e pode ser instalado no seu dispositivo móvel.

## Como Instalar no Android

### Opção 1: Via Chrome
1. Abra o site no Google Chrome
2. Toque no menu (⋮) no canto superior direito
3. Selecione "Adicionar à tela inicial" ou "Instalar app"
4. Confirme tocando em "Instalar"
5. O ícone do app aparecerá na sua tela inicial

### Opção 2: Banner de Instalação
1. Ao visitar o site, um banner aparecerá automaticamente
2. Toque em "Instalar" no banner
3. Confirme a instalação

## Como Instalar no iOS (iPhone/iPad)

1. Abra o site no Safari
2. Toque no botão de compartilhar (□↑)
3. Role para baixo e toque em "Adicionar à Tela de Início"
4. Digite um nome (Maternia) e toque em "Adicionar"
5. O ícone do app aparecerá na sua tela inicial

## Benefícios do App Instalado

- ✅ Acesso rápido direto da tela inicial
- ✅ Funciona offline após primeira visita
- ✅ Experiência de app nativo
- ✅ Notificações push (em breve)
- ✅ Não ocupa muito espaço (menos de 5MB)
- ✅ Atualizações automáticas

## Requisitos

- Android: Chrome 40+ ou navegador compatível
- iOS: Safari 11.3+
- Conexão com internet para primeira instalação

## Problemas Comuns

**App não aparece para instalar:**
- Certifique-se de estar usando Chrome (Android) ou Safari (iOS)
- Verifique se o site está carregado via HTTPS
- Limpe o cache do navegador e tente novamente

**App instalado não abre:**
- Desinstale e reinstale o app
- Limpe os dados do navegador
- Verifique se tem espaço de armazenamento disponível
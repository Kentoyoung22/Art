# Guia de Conexão com o Banco de Dados

## Problema: TypeError: Failed to fetch

Este erro ocorre quando o sistema tenta acessar o banco de dados Trickle antes dele estar completamente carregado.

## Soluções Implementadas

### 1. Inicialização Robusta do Banco de Dados
- **Script dedicado**: `utils/dbInit.js` carregado primeiro
- **Verificação contínua**: a cada 500ms até 40 tentativas (20 segundos)
- **Espera adicional**: 2 segundos após detectar as funções para garantir estabilidade
- **Verificação completa**: Confirma que todas as 5 funções do Trickle DB estão disponíveis

### 2. Lógica de Retry nas Operações
- **Número de tentativas**: até 8 tentativas para login, 5 para outras operações
- **Delay crescente**: 3 segundos × número da tentativa (máximo 10s)
- **Verificação antes de retry**: Confirma disponibilidade das funções antes de cada tentativa

### 3. Ordem de Carregamento de Scripts
Os scripts são carregados nesta ordem específica:
1. `utils/dbInit.js` - Inicialização e funções de retry do banco de dados
2. `utils/auth.js` - Funções de autenticação
3. `components/Alert.js` - Componente de alerta
4. `login-app.js` - Aplicação principal

### 4. Mensagens de Feedback ao Usuário
- Mensagem de carregamento inicial informa que o sistema está conectando ao banco
- Mensagens de erro são específicas e orientam o usuário

## Passos de Diagnóstico

Se o erro persistir:

1. **Verifique o console do navegador** para mensagens detalhadas
2. **Aguarde pelo menos 30-40 segundos** após carregar a página
3. **Teste a conexão de internet**
4. **Limpe o cache do navegador** e recarregue com Ctrl+Shift+R
5. **Tente em modo anônimo/privado**
6. **Verifique se outros apps Trickle funcionam**

## Quando Reportar

Se após seguir todos os passos acima o erro persistir, reporte:
- Mensagens de erro completas do console
- Navegador e versão
- Tempo decorrido antes do erro
- Se outros aplicativos Trickle funcionam
- Logs de tentativas de conexão

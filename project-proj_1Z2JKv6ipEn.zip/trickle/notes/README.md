# Sistema Pré-Natal

Sistema Inteligente de Acompanhamento Pré-Natal para Moçambique

## Visão Geral

Plataforma digital integrada para melhorar a adesão das gestantes às consultas pré-natais, otimizar o acompanhamento da saúde materno-infantil e utilizar inteligência artificial para triagem preditiva de riscos.

## Estrutura do Sistema

### Páginas Principais

- **index.html** - Página de login
- **admin.html** - Painel administrativo
- **professional.html** - Painel do profissional de saúde
- **patient.html** - Painel da paciente/gestante

### Usuário Padrão

- **Admin**
  - Email: admin@gmail.com
  - Senha: Natal2025!

## Funcionalidades

### Administrador
- Gestão de usuários profissionais
- Ativar/desativar usuários
- Criar novos profissionais de saúde

### Profissional de Saúde
- Cadastrar pacientes
- Monitorar pacientes
- Visualizar avaliações de risco

### Paciente/Gestante
- Dashboard com informações de saúde
- Autoavaliação de sintomas com IA
- Dicas de autocuidado
- Acompanhamento de consultas

## Tecnologias

- React 18
- TailwindCSS
- Trickle Database
- AI Integration (OpenRouter API)
- PWA (Progressive Web App)

## Instalação como App

O sistema está disponível como Progressive Web App (PWA) e pode ser instalado em dispositivos móveis Android e iOS. Consulte o guia `trickle/notes/pwa_installation_guide.md` para instruções detalhadas.

### Recursos PWA
- Instalação na tela inicial
- Funciona offline
- Experiência de app nativo
- Atualizações automáticas

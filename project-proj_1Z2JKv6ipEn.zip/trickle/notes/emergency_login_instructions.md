# Instruções de Login em Caso de Problemas

## Erro: "Failed to fetch" ou "Erro ao conectar"

Se você está recebendo erros ao tentar fazer login, siga estes passos:

### Passo 1: Recarregue Completamente
- **Windows/Linux**: Pressione `Ctrl + Shift + R`
- **Mac**: Pressione `Cmd + Shift + R`

### Passo 2: Aguarde
- Após recarregar, **espere pelo menos 30 segundos**
- O botão de login deve mudar de "Aguarde..." para "Entrar"
- Só tente fazer login quando o botão mostrar "Entrar"

### Passo 3: Tente Login
- Use suas credenciais normais
- O sistema tentará automaticamente até 8 vezes com intervalos crescentes

### Passo 4: Se Ainda Falhar
1. Limpe o cache do navegador
2. Feche e reabra o navegador
3. Tente em modo anônimo/privado
4. Verifique sua conexão de internet

## Credenciais Padrão Admin
- Email: admin@gmail.com
- Senha: Natal2025!

## Nota Técnica
O sistema usa o banco de dados Trickle que precisa de alguns segundos para inicializar completamente. A espera inicial garante que todas as funções do banco estejam disponíveis antes de permitir o login.
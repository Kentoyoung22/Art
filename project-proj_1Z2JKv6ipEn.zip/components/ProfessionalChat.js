function ProfessionalChat({ setAlert, onViewChange }) {
  try {
    const [patients, setPatients] = React.useState([]);
    const [selectedPatient, setSelectedPatient] = React.useState(null);
    const [messages, setMessages] = React.useState([]);
    const [newMessage, setNewMessage] = React.useState('');
    const [loading, setLoading] = React.useState(true);
    const [sending, setSending] = React.useState(false);

    React.useEffect(() => {
      loadPatients();
    }, []);

    React.useEffect(() => {
      if (selectedPatient) {
        loadMessages();
        markMessagesAsRead();
      }
    }, [selectedPatient]);

    const loadPatients = async () => {
      try {
        const user = getCurrentUser();
        const result = await trickleListObjects('user', 100, true);
        if (result && result.items) {
          const myPatients = result.items.filter(p => 
            p.objectData && p.objectData.role === 'patient' && p.objectData.professionalId === user.id
          );
          setPatients(myPatients);
        }
      } catch (error) {
        console.error('Error loading patients:', error);
      } finally {
        setLoading(false);
      }
    };

    const loadMessages = async () => {
      try {
        const user = getCurrentUser();
        const result = await trickleListObjects('message', 100, false);
        if (result && result.items) {
          const chatMessages = result.items.filter(m => 
            m.objectData && (
              (m.objectData.senderId === user.id && m.objectData.receiverId === selectedPatient.objectId) ||
              (m.objectData.receiverId === user.id && m.objectData.senderId === selectedPatient.objectId)
            )
          );
          setMessages(chatMessages);
        }
      } catch (error) {
        console.error('Error loading messages:', error);
      }
    };

    const markMessagesAsRead = async () => {
      try {
        const user = getCurrentUser();
        const unreadMessages = messages.filter(m => 
          m.objectData && m.objectData.receiverId === user.id && !m.objectData.read
        );
        
        for (const msg of unreadMessages) {
          await trickleUpdateObject('message', msg.objectId, {
            ...msg.objectData,
            read: true
          });
        }
      } catch (error) {
        console.error('Error marking messages as read:', error);
      }
    };

    const sendMessage = async (e) => {
      e.preventDefault();
      if (!newMessage.trim() || !selectedPatient) return;
      
      setSending(true);
      try {
        const user = getCurrentUser();
        
        await trickleCreateObject('message', {
          senderId: user.id,
          senderName: user.name,
          receiverId: selectedPatient.objectId,
          content: newMessage,
          read: false,
          createdAt: new Date().toISOString()
        });
        
        await trickleCreateObject('notification', {
          userId: selectedPatient.objectId,
          title: 'Nova Mensagem do Profissional',
          message: `${user.name} respondeu: "${newMessage.substring(0, 50)}${newMessage.length > 50 ? '...' : ''}"`,
          type: 'message',
          read: false,
          createdAt: new Date().toISOString()
        });
        
        setNewMessage('');
        loadMessages();
      } catch (error) {
        console.error('Error sending message:', error);
        setAlert({ type: 'error', message: 'Erro ao enviar mensagem' });
      } finally {
        setSending(false);
      }
    };

    if (loading) {
      return <div className="text-center py-8">Carregando...</div>;
    }

    return (
      <div>
        <button onClick={() => onViewChange('dashboard')} className="btn btn-primary mb-4">
          <div className="flex items-center space-x-2">
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar ao Painel</span>
          </div>
        </button>
        <h2 className="text-2xl font-bold mb-6">Conversar com Pacientes</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="bg-white rounded-lg shadow p-4">
            <h3 className="font-semibold mb-4">Pacientes</h3>
            <div className="space-y-2">
              {patients.map(patient => (
                <button
                  key={patient.objectId}
                  onClick={() => setSelectedPatient(patient)}
                  className={`w-full text-left p-3 rounded-lg transition-colors ${
                    selectedPatient?.objectId === patient.objectId 
                      ? 'bg-blue-100 border-2 border-[var(--primary-color)]' 
                      : 'hover:bg-gray-100'
                  }`}
                >
                  <p className="font-medium">{patient.objectData.name}</p>
                </button>
              ))}
            </div>
          </div>

          <div className="lg:col-span-2 bg-white rounded-lg shadow">
            {selectedPatient ? (
              <>
                <div className="border-b p-4">
                  <h3 className="font-semibold">{selectedPatient.objectData.name}</h3>
                </div>
                <div className="h-96 overflow-y-auto p-6 space-y-4">
                  {messages.map(msg => {
                    const user = getCurrentUser();
                    const isSender = msg.objectData.senderId === user.id;
                    return (
                      <div key={msg.objectId} className={`flex ${isSender ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                          isSender ? 'bg-[var(--primary-color)] text-white' : 'bg-gray-100 text-gray-900'
                        }`}>
                          <p className="text-sm">{msg.objectData.content}</p>
                          <p className={`text-xs mt-1 ${isSender ? 'text-blue-100' : 'text-gray-500'}`}>
                            {new Date(msg.createdAt).toLocaleString('pt-PT')}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <form onSubmit={sendMessage} className="border-t p-4">
                  <div className="flex space-x-4">
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Digite sua mensagem..."
                      className="flex-1 px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)]"
                    />
                    <button type="submit" className="btn-primary" disabled={sending}>
                      {sending ? 'Enviando...' : 'Enviar'}
                    </button>
                  </div>
                </form>
              </>
            ) : (
              <div className="flex items-center justify-center h-full text-gray-500 p-8">
                Selecione uma paciente para iniciar a conversa
              </div>
            )}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ProfessionalChat error:', error);
    return null;
  }
}
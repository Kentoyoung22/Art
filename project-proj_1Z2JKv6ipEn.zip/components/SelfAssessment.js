function SelfAssessment({ setAlert }) {
  try {
    const [currentStep, setCurrentStep] = React.useState(1);
    const [answers, setAnswers] = React.useState({});
    const [loading, setLoading] = React.useState(false);
    const [result, setResult] = React.useState(null);
    const [previousAssessments, setPreviousAssessments] = React.useState([]);
    const [personalizedQuestions, setPersonalizedQuestions] = React.useState([]);

    React.useEffect(() => {
      loadPreviousAssessments();
    }, []);

    const loadPreviousAssessments = async () => {
      try {
        const user = getCurrentUser();
        const result = await trickleListObjects('assessment', 100, true);
        if (result && result.items) {
          const userAssessments = result.items.filter(a => 
            a.objectData && a.objectData.patientId === user.id
          );
          setPreviousAssessments(userAssessments);
          generatePersonalizedQuestions(userAssessments);
        } else {
          setDefaultQuestions();
        }
      } catch (error) {
        console.error('Error loading assessments:', error);
        setDefaultQuestions();
      }
    };

    const setDefaultQuestions = () => {
      setPersonalizedQuestions(getDefaultQuestions());
    };

    const getDefaultQuestions = () => [
      {
        step: 1,
        title: "Sintomas Gerais",
        questions: [
          { id: 'headache', text: 'Tem sentido dores de cabeça intensas ou persistentes?', type: 'radio', options: ['Não', 'Leve', 'Moderada', 'Intensa'] },
          { id: 'dizziness', text: 'Tem tido tonturas ou sensação de desmaio?', type: 'radio', options: ['Não', 'Raramente', 'Frequentemente', 'Muito frequentemente'] },
          { id: 'vision', text: 'Tem problemas de visão (visão embaçada, manchas, luzes)?', type: 'radio', options: ['Não', 'Ocasionalmente', 'Frequentemente'] }
        ]
      },
      {
        step: 2,
        title: "Sintomas Abdominais e Digestivos",
        questions: [
          { id: 'abdominal_pain', text: 'Sente dor abdominal?', type: 'radio', options: ['Não', 'Leve', 'Moderada', 'Intensa'] },
          { id: 'nausea', text: 'Tem náuseas ou vômitos?', type: 'radio', options: ['Não', 'Ocasionalmente', 'Diariamente', 'Várias vezes ao dia'] },
          { id: 'contractions', text: 'Tem contrações ou endurecimento da barriga frequente?', type: 'radio', options: ['Não', 'Raramente', 'Frequentemente'] }
        ]
      },
      {
        step: 3,
        title: "Sangramento e Corrimento",
        questions: [
          { id: 'bleeding', text: 'Tem tido sangramento vaginal?', type: 'radio', options: ['Não', 'Leve (gotas)', 'Moderado', 'Intenso'] },
          { id: 'discharge', text: 'Notou corrimento com cheiro forte ou cor anormal?', type: 'radio', options: ['Não', 'Sim, leve', 'Sim, intenso'] },
          { id: 'fluid_loss', text: 'Teve perda de líquido pela vagina?', type: 'radio', options: ['Não', 'Sim, pouco', 'Sim, muito'] }
        ]
      },
      {
        step: 4,
        title: "Inchaço e Circulação",
        questions: [
          { id: 'swelling', text: 'Tem inchaço nas mãos, pés ou rosto?', type: 'radio', options: ['Não', 'Leve', 'Moderado', 'Intenso'] },
          { id: 'swelling_sudden', text: 'O inchaço apareceu de forma súbita?', type: 'radio', options: ['Não', 'Sim'] },
          { id: 'breath', text: 'Tem dificuldade para respirar?', type: 'radio', options: ['Não', 'Ocasionalmente', 'Frequentemente'] }
        ]
      },
      {
        step: 5,
        title: "Movimentos do Bebê",
        questions: [
          { id: 'baby_movement', text: 'O bebê está se movimentando normalmente?', type: 'radio', options: ['Sim, normal', 'Menos que o usual', 'Muito menos', 'Não sinto movimentos'] },
          { id: 'movement_change', text: 'Notou mudança súbita nos movimentos do bebê?', type: 'radio', options: ['Não', 'Sim'] }
        ]
      }
    ];

    const generatePersonalizedQuestions = (assessments) => {
      if (assessments.length === 0) {
        setDefaultQuestions();
        return;
      }

      const lastAssessment = assessments[0];
      const lastAnswers = lastAssessment.objectData.answers || {};
      
      const baseQuestions = getDefaultQuestions();
      const personalized = baseQuestions.map(section => {
        const filteredQuestions = section.questions.filter(q => {
          const lastAnswer = lastAnswers[q.id];
          if (!lastAnswer || lastAnswer === 'Não' || lastAnswer === 'Sim, normal') {
            return Math.random() > 0.3;
          }
          return true;
        });

        if (filteredQuestions.length === 0) {
          return {
            ...section,
            questions: section.questions.slice(0, 2)
          };
        }

        return {
          ...section,
          questions: filteredQuestions
        };
      }).filter(section => section.questions.length > 0);

      setPersonalizedQuestions(personalized.length > 0 ? personalized : getDefaultQuestions());
    };

    const questions = personalizedQuestions.length > 0 ? personalizedQuestions : getDefaultQuestions();
    const currentQuestions = questions.find(q => q.step === currentStep);
    const totalSteps = questions.length;

    const handleAnswer = (questionId, value) => {
      setAnswers({ ...answers, [questionId]: value });
    };

    const canProceed = () => {
      const currentQuestionIds = currentQuestions.questions.map(q => q.id);
      return currentQuestionIds.every(id => answers[id]);
    };

    const nextStep = () => {
      if (currentStep < totalSteps) {
        setCurrentStep(currentStep + 1);
      } else {
        submitAssessment();
      }
    };

    const prevStep = () => {
      if (currentStep > 1) {
        setCurrentStep(currentStep - 1);
      }
    };

    const submitAssessment = async () => {
      setLoading(true);
      try {
        const criticalSymptoms = {
          bleeding: ['Moderado', 'Intenso'].includes(answers.bleeding),
          severeHeadache: answers.headache === 'Intensa',
          visionProblems: answers.vision === 'Frequentemente',
          severePain: answers.abdominal_pain === 'Intensa',
          fluidLoss: ['Sim, muito'].includes(answers.fluid_loss),
          noMovement: ['Muito menos', 'Não sinto movimentos'].includes(answers.baby_movement)
        };

        const criticalCount = Object.values(criticalSymptoms).filter(v => v).length;
        
        let riskLevel, analysis, recommendations;
        
        if (criticalCount >= 2 || criticalSymptoms.noMovement || criticalSymptoms.bleeding) {
          riskLevel = 'high';
          analysis = 'ATENÇÃO: Sua avaliação indica sintomas que requerem atenção médica URGENTE.';
          recommendations = [
            'Procure atendimento médico IMEDIATAMENTE',
            'Entre em contato com seu profissional através do chat',
            'Não espere - vá ao hospital se os sintomas piorarem'
          ];
        } else if (criticalCount === 1 || answers.swelling === 'Intenso') {
          riskLevel = 'medium';
          analysis = 'Sua avaliação indica sintomas que merecem atenção nas próximas 24-48 horas.';
          recommendations = [
            'Entre em contato com seu profissional através do chat',
            'Agende uma consulta para avaliação',
            'Monitore seus sintomas'
          ];
        } else {
          riskLevel = 'low';
          analysis = 'Sua avaliação indica sintomas normais. Continue os cuidados pré-natais de rotina.';
          recommendations = [
            'Mantenha suas consultas regulares',
            'Continue com alimentação saudável',
            'Monitore os movimentos do bebê'
          ];
        }

        setResult({ riskLevel, analysis, recommendations });
        
        const user = getCurrentUser();
        if (user && user.id) {
          await trickleCreateObject('assessment', {
            patientId: user.id,
            answers: answers,
            riskLevel: riskLevel,
            analysis: analysis,
            recommendations: recommendations,
            date: new Date().toISOString()
          });
        }
        
        setAlert({ type: 'success', message: 'Avaliação concluída' });
      } catch (error) {
        console.error('Error submitting assessment:', error);
        setAlert({ type: 'error', message: 'Erro ao processar avaliação' });
      } finally {
        setLoading(false);
      }
    };

    const getRiskColor = (level) => {
      if (level === 'low') return 'bg-green-100 text-green-800 border-green-300';
      if (level === 'medium') return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      return 'bg-red-100 text-red-800 border-red-300';
    };

    const restartAssessment = () => {
      setCurrentStep(1);
      setAnswers({});
      setResult(null);
    };

    if (result) {
      return (
        <div className="max-w-3xl mx-auto">
          <div className="bg-white rounded-lg shadow p-6">
            <div className={`border-l-4 p-6 rounded-lg mb-6 ${getRiskColor(result.riskLevel)}`}>
              <div className="flex items-center mb-4">
                <div className={`icon-${result.riskLevel === 'high' ? 'alert-triangle' : result.riskLevel === 'medium' ? 'alert-circle' : 'check-circle'} text-3xl mr-3`}></div>
                <h3 className="text-2xl font-bold">
                  Risco {result.riskLevel === 'low' ? 'Baixo' : result.riskLevel === 'medium' ? 'Médio' : 'Alto'}
                </h3>
              </div>
              <p className="text-lg mb-4">{result.analysis}</p>
            </div>

            <div className="mb-6">
              <h4 className="text-xl font-semibold mb-4">Recomendações:</h4>
              <ul className="space-y-3">
                {result.recommendations.map((rec, i) => (
                  <li key={i} className="flex items-start">
                    <div className="icon-check text-green-600 mr-3 mt-1"></div>
                    <span className="text-gray-700">{rec}</span>
                  </li>
                ))}
              </ul>
            </div>

            {result.riskLevel !== 'low' && (
              <div className="bg-pink-50 border border-pink-200 rounded-lg p-4 mb-6">
                <div className="flex items-center">
                  <div className="icon-message-circle text-pink-600 text-2xl mr-3"></div>
                  <div>
                    <h5 className="font-semibold text-pink-900">Precisa de ajuda?</h5>
                    <p className="text-sm text-pink-700">Converse com seu profissional</p>
                  </div>
                  <button onClick={() => window.location.href = 'patient.html#chat'} className="ml-auto btn-primary">
                    Ir às Conversas
                  </button>
                </div>
              </div>
            )}

            <div className="flex gap-4">
              <button onClick={restartAssessment} className="btn-primary flex-1">
                Nova Avaliação
              </button>
              <button onClick={() => window.location.href = 'patient.html'} className="bg-gray-200 text-gray-700 px-6 py-3 rounded-lg font-medium hover:bg-gray-300 flex-1">
                Voltar
              </button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="max-w-3xl mx-auto pb-24 md:pb-0">
        <button onClick={() => window.location.href = 'patient.html'} className="btn-primary mb-4">
          <div className="flex items-center space-x-2">
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar ao Painel</span>
          </div>
        </button>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold">Autoavaliação</h2>
              <span className="text-sm text-gray-600">Etapa {currentStep} de {totalSteps}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-[var(--primary-color)] h-2 rounded-full transition-all"
                style={{ width: `${(currentStep / totalSteps) * 100}%` }}
              ></div>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-xl font-semibold mb-4">{currentQuestions.title}</h3>
            <div className="space-y-6">
              {currentQuestions.questions.map((question, index) => (
                <div key={question.id} className="border-b pb-4">
                  <p className="font-medium mb-3">{index + 1}. {question.text}</p>
                  <div className="space-y-2">
                    {question.options.map((option) => (
                      <label key={option} className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                        <input
                          type="radio"
                          name={question.id}
                          value={option}
                          checked={answers[question.id] === option}
                          onChange={(e) => handleAnswer(question.id, e.target.value)}
                          className="w-4 h-4"
                        />
                        <span>{option}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-4">
            {currentStep > 1 && (
              <button onClick={prevStep} className="bg-gray-200 text-gray-700 px-6 py-3 rounded-lg font-medium hover:bg-gray-300">
                Anterior
              </button>
            )}
            <button 
              onClick={nextStep}
              disabled={!canProceed() || loading}
              className="btn-primary flex-1 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Processando...' : currentStep === totalSteps ? 'Finalizar' : 'Próxima'}
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('SelfAssessment error:', error);
    return null;
  }
}
function UserManagement({ setAlert, onViewChange }) {
  try {
    const [users, setUsers] = React.useState([]);
    const [showModal, setShowModal] = React.useState(false);
    const [formData, setFormData] = React.useState({ name: '', email: '', password: '', role: 'professional' });

    React.useEffect(() => {
      loadUsers();
    }, []);

    const loadUsers = async () => {
      try {
        const result = await trickleListObjects('user', 100, true);
        if (result && result.items) {
          setUsers(result.items.filter(u => u.objectData.role !== 'admin'));
        }
      } catch (error) {
        setAlert({ type: 'error', message: 'Erro ao carregar usuários' });
      }
    };

    const handleCreate = async (e) => {
      e.preventDefault();
      try {
        await trickleCreateObject('user', { ...formData, active: true });
        setAlert({ type: 'success', message: 'Usuário criado com sucesso' });
        setShowModal(false);
        setFormData({ name: '', email: '', password: '', role: 'professional' });
        loadUsers();
      } catch (error) {
        setAlert({ type: 'error', message: 'Erro ao criar usuário' });
      }
    };

    const toggleActive = async (user) => {
      try {
        await trickleUpdateObject('user', user.objectId, { ...user.objectData, active: !user.objectData.active });
        setAlert({ type: 'success', message: 'Status atualizado' });
        loadUsers();
      } catch (error) {
        setAlert({ type: 'error', message: 'Erro ao atualizar status' });
      }
    };

    return (
      <div>
        <button onClick={() => onViewChange('dashboard')} className="btn btn-secondary mb-4">
          <div className="icon-arrow-left text-lg"></div>
          Voltar ao Painel
        </button>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Gestão de Usuários</h2>
          <button onClick={() => setShowModal(true)} className="btn btn-primary">
            <div className="icon-plus text-lg"></div>
            <span>Novo Usuário</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {users.map(user => (
            <div key={user.objectId} className="card animate-slide-in">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <div className="icon-user text-xl text-blue-600"></div>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{user.objectData.name}</h3>
                    <p className="text-sm text-gray-500">{user.objectData.email}</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Função:</span>
                  <span className="font-medium">{user.objectData.role === 'professional' ? 'Profissional' : 'Paciente'}</span>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Status:</span>
                  <span className={`px-2 py-1 text-xs rounded-full ${user.objectData.active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {user.objectData.active ? 'Ativo' : 'Inativo'}
                  </span>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t">
                <button
                  onClick={() => toggleActive(user)}
                  className={`w-full btn ${user.objectData.active ? 'btn-danger' : 'btn-success'} btn-sm justify-center`}
                >
                  {user.objectData.active ? 'Desativar' : 'Ativar'}
                </button>
              </div>
            </div>
          ))}
        </div>

        {showModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-2xl p-8 max-w-md w-full">
              <div className="flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mx-auto mb-4">
                <div className="icon-user-plus text-2xl text-green-600"></div>
              </div>
              <h3 className="text-2xl font-bold text-center mb-6">Novo Usuário</h3>
              <form onSubmit={handleCreate} className="space-y-5">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Nome Completo</label>
                  <input
                    type="text"
                    placeholder="Ex: João Silva"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="input-field"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Email</label>
                  <input
                    type="email"
                    placeholder="email@exemplo.com"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="input-field"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Senha</label>
                  <input
                    type="password"
                    placeholder="Mínimo 6 caracteres"
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    className="input-field"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Função</label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({...formData, role: e.target.value})}
                    className="input-field"
                  >
                    <option value="professional">Profissional</option>
                  </select>
                </div>
                <div className="flex gap-3 pt-2">
                  <button type="submit" className="btn-primary flex-1 py-3 font-semibold">Criar</button>
                  <button type="button" onClick={() => setShowModal(false)} className="btn-secondary flex-1 py-3 font-semibold">Cancelar</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('UserManagement error:', error);
    return null;
  }
}

function AdminHeader({ currentView, onViewChange }) {
  try {
    const user = getCurrentUser();

    return (
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-6 py-5">
          <div className="flex items-center justify-between">
            <button onClick={() => onViewChange('dashboard')} className="flex items-center space-x-3 hover:opacity-80 transition-opacity">
              <div className="w-12 h-12 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
                <div className="icon-heart text-2xl text-white"></div>
              </div>
              <span className="text-2xl font-bold text-[var(--text-dark)]">Maternia</span>
            </button>
            <div className="flex items-center space-x-6">
              <button onClick={() => onViewChange('password')} className="flex items-center space-x-3 hover:opacity-80 transition-opacity">
                <div className="w-10 h-10 bg-gradient-to-br from-[var(--primary-color)] to-pink-400 rounded-full flex items-center justify-center shadow-md">
                  <div className="icon-user text-lg text-white"></div>
                </div>
                <span className="text-sm font-medium text-[var(--text-dark)]">{user?.name}</span>
              </button>
              <button onClick={logout} className="px-6 py-2.5 bg-[var(--accent-color)] text-[var(--primary-color)] rounded-full font-medium hover:bg-[#FFE5EC] transition-colors">
                Sair
              </button>
            </div>
          </div>
        </div>
      </header>
    );
  } catch (error) {
    console.error('AdminHeader error:', error);
    return null;
  }
}

function ChatWithProfessional({ setAlert }) {
  try {
    const [messages, setMessages] = React.useState([]);
    const [newMessage, setNewMessage] = React.useState('');
    const [loading, setLoading] = React.useState(true);
    const [sending, setSending] = React.useState(false);

    React.useEffect(() => {
      loadMessages();
    }, []);

    const loadMessages = async () => {
      try {
        const user = getCurrentUser();
        if (!user || !user.id) {
          setLoading(false);
          return;
        }
        
        const result = await trickleListObjects('message', 100, false);
        if (result && result.items) {
          const userMessages = result.items.filter(m => 
            m.objectData && (m.objectData.senderId === user.id || m.objectData.receiverId === user.id)
          );
          setMessages(userMessages);
        }
      } catch (error) {
        console.error('Error loading messages:', error);
      } finally {
        setLoading(false);
      }
    };

    const sendMessage = async (e) => {
      e.preventDefault();
      if (!newMessage.trim()) return;
      
      setSending(true);
      try {
        const user = getCurrentUser();
        const usersResult = await trickleListObjects('user', 100, true);
        const currentUserData = usersResult.items.find(u => u.objectId === user.id);
        
        if (!currentUserData || !currentUserData.objectData.professionalId) {
          setAlert({ type: 'error', message: 'Profissional não atribuído' });
          setSending(false);
          return;
        }
        
        await trickleCreateObject('message', {
          senderId: user.id,
          senderName: user.name,
          receiverId: currentUserData.objectData.professionalId,
          content: newMessage,
          read: false,
          createdAt: new Date().toISOString()
        });
        
        await trickleCreateObject('notification', {
          userId: currentUserData.objectData.professionalId,
          title: 'Nova Mensagem',
          message: `${user.name} enviou uma mensagem: "${newMessage.substring(0, 50)}${newMessage.length > 50 ? '...' : ''}"`,
          type: 'message',
          read: false,
          messageId: user.id,
          createdAt: new Date().toISOString()
        });
        
        setNewMessage('');
        loadMessages();
        setAlert({ type: 'success', message: 'Mensagem enviada' });
      } catch (error) {
        console.error('Error sending message:', error);
        setAlert({ type: 'error', message: 'Erro ao enviar mensagem' });
      } finally {
        setSending(false);
      }
    };

    if (loading) {
      return <div className="text-center py-8">Carregando mensagens...</div>;
    }

    return (
      <div className="max-w-4xl mx-auto pb-24 md:pb-0">
        <button onClick={() => window.location.href = 'patient.html'} className="btn-primary mb-4">
          <div className="flex items-center space-x-2">
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar ao Painel</span>
          </div>
        </button>
        <h2 className="text-2xl font-bold mb-6">Conversas com Profissional</h2>
        
        <div className="bg-white rounded-lg shadow">
          <div className="h-96 overflow-y-auto p-6 space-y-4">
            {messages.length === 0 ? (
              <div className="text-center text-gray-500 py-8">
                <div className="icon-message-circle text-4xl text-gray-300 mb-4"></div>
                <p>Nenhuma mensagem ainda</p>
              </div>
            ) : (
              messages.map(msg => {
                const user = getCurrentUser();
                const isSender = msg.objectData.senderId === user.id;
                return (
                  <div key={msg.objectId} className={`flex ${isSender ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                      isSender ? 'bg-[var(--primary-color)] text-white' : 'bg-gray-100 text-gray-900'
                    }`}>
                      <p className="text-sm">{msg.objectData.content}</p>
                      <p className={`text-xs mt-1 ${isSender ? 'text-blue-100' : 'text-gray-500'}`}>
                        {new Date(msg.createdAt).toLocaleString('pt-PT')}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
          
          <form onSubmit={sendMessage} className="border-t p-4">
            <div className="flex space-x-4">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Digite sua mensagem..."
                className="flex-1 px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)]"
              />
              <button type="submit" className="btn-primary" disabled={sending}>
                {sending ? 'Enviando...' : 'Enviar'}
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ChatWithProfessional error:', error);
    return null;
  }
}
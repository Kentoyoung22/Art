function BackupManager({ setAlert, onViewChange }) {
  try {
    const [backups, setBackups] = React.useState([]);
    const [loading, setLoading] = React.useState(false);
    const fileInputRef = React.useRef(null);

    const createBackup = async () => {
      setLoading(true);
      try {
        const users = await trickleListObjects('user', 1000, true);
        const assessments = await trickleListObjects('assessment', 1000, true);
        const appointments = await trickleListObjects('appointment', 1000, true);
        const logs = await trickleListObjects('system_log', 1000, true);
        
        const backupData = {
          date: new Date().toISOString(),
          users: users.items,
          assessments: assessments.items,
          appointments: appointments.items,
          logs: logs.items
        };
        
        const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `backup-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        await trickleCreateObject('system_log', {
          userId: getCurrentUser().id,
          userName: getCurrentUser().name,
          userRole: getCurrentUser().role,
          action: 'backup',
          description: `${getCurrentUser().name} criou backup do sistema`,
          ipAddress: 'N/A',
          timestamp: new Date().toISOString()
        });
        
        const backup = {
          id: Date.now(),
          date: new Date().toISOString(),
          size: `${(blob.size / 1024).toFixed(2)} KB`
        };
        setBackups([backup, ...backups]);
        setAlert({ type: 'success', message: 'Backup criado e baixado com sucesso' });
      } catch (error) {
        console.error('Error creating backup:', error);
        setAlert({ type: 'error', message: 'Erro ao criar backup' });
      } finally {
        setLoading(false);
      }
    };

    const handleRestore = () => {
      fileInputRef.current?.click();
    };

    const restoreBackup = async (event) => {
      const file = event.target.files?.[0];
      if (!file) return;
      
      setLoading(true);
      try {
        const text = await file.text();
        const backupData = JSON.parse(text);
        
        setAlert({ type: 'success', message: `Backup de ${new Date(backupData.date).toLocaleDateString('pt-PT')} lido com sucesso. Funcionalidade de restauração em desenvolvimento.` });
        
        await trickleCreateObject('system_log', {
          userId: getCurrentUser().id,
          userName: getCurrentUser().name,
          userRole: getCurrentUser().role,
          action: 'restore',
          description: `${getCurrentUser().name} tentou restaurar backup`,
          ipAddress: 'N/A',
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        console.error('Error restoring backup:', error);
        setAlert({ type: 'error', message: 'Erro ao ler arquivo de backup' });
      } finally {
        setLoading(false);
        event.target.value = '';
      }
    };

    return (
      <div>
        <button onClick={() => onViewChange('dashboard')} className="btn btn-secondary mb-4">
          <div className="icon-arrow-left text-lg"></div>
          Voltar ao Painel
        </button>

        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <h2 className="text-2xl font-bold">Gestão de Backups</h2>
          <div className="flex gap-3 w-full sm:w-auto">
            <button onClick={handleRestore} className="btn btn-secondary flex-1 sm:flex-none" disabled={loading}>
              <div className="icon-upload text-lg"></div>
              Restaurar Backup
            </button>
            <button onClick={createBackup} className="btn btn-primary flex-1 sm:flex-none" disabled={loading}>
              <div className="icon-download text-lg"></div>
              {loading ? 'Criando...' : 'Criar Backup'}
            </button>
          </div>
        </div>

        <input 
          ref={fileInputRef}
          type="file" 
          accept=".json"
          onChange={restoreBackup}
          className="hidden"
        />

        <div className="card">
          <h3 className="font-semibold mb-4">Backups Recentes</h3>
          {backups.length === 0 ? (
            <p className="text-gray-500 text-center py-8">Nenhum backup criado nesta sessão</p>
          ) : (
            <div className="space-y-3">
              {backups.map(backup => (
                <div key={backup.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 border rounded">
                  <div>
                    <p className="font-medium">{new Date(backup.date).toLocaleString('pt-PT')}</p>
                    <p className="text-sm text-gray-500">{backup.size}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('BackupManager error:', error);
    return null;
  }
}
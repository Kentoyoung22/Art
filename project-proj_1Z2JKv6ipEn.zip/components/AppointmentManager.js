function AppointmentManager({ setAlert, onViewChange }) {
  try {
    const [patients, setPatients] = React.useState([]);
    const [showModal, setShowModal] = React.useState(false);
    const [formData, setFormData] = React.useState({
      patientId: '',
      date: '',
      type: 'Consulta Pré-Natal',
      status: 'Agendada',
      notes: ''
    });

    React.useEffect(() => {
      loadPatients();
    }, []);

    const loadPatients = async () => {
      try {
        const user = getCurrentUser();
        if (!user || !user.id) return;
        
        const result = await trickleListObjects('user', 100, true);
        if (result && result.items) {
          const myPatients = result.items.filter(u => 
            u.objectData && u.objectData.role === 'patient' && u.objectData.professionalId === user.id
          );
          setPatients(myPatients);
        } else {
          setPatients([]);
        }
      } catch (error) {
        console.error('Error loading patients:', error);
        setPatients([]);
      }
    };

    const handleCreate = async (e) => {
      e.preventDefault();
      try {
        const user = getCurrentUser();
        if (!user || !user.id) return;
        
        await trickleCreateObject('appointment', {
          patientId: formData.patientId,
          professionalId: user.id,
          date: formData.date,
          type: formData.type,
          status: formData.status,
          notes: formData.notes
        });
        
        await trickleCreateObject('notification', {
          userId: formData.patientId,
          title: 'Nova Consulta Agendada',
          message: `Consulta de ${formData.type} agendada para ${new Date(formData.date).toLocaleDateString('pt-PT')}`,
          type: 'appointment',
          read: false,
          createdAt: new Date().toISOString()
        });
        
        setAlert({ type: 'success', message: 'Consulta agendada com sucesso' });
        setShowModal(false);
        setFormData({
          patientId: '',
          date: '',
          type: 'Consulta Pré-Natal',
          status: 'Agendada',
          notes: ''
        });
      } catch (error) {
        console.error('Error creating appointment:', error);
        setAlert({ type: 'error', message: 'Erro ao agendar consulta' });
      }
    };

    return (
      <div>
        <button onClick={() => onViewChange('dashboard')} className="btn btn-primary mb-4">
          <div className="flex items-center space-x-2">
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar ao Painel</span>
          </div>
        </button>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Gestão de Consultas</h2>
          <button onClick={() => setShowModal(true)} className="btn-primary">
            <div className="flex items-center space-x-2">
              <div className="icon-plus text-lg"></div>
              <span>Agendar Consulta</span>
            </div>
          </button>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <p className="text-gray-600">
            Selecione "Agendar Consulta" para criar novas consultas para suas pacientes.
          </p>
        </div>

        {showModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-8 max-w-md w-full">
              <h3 className="text-xl font-bold mb-4">Agendar Nova Consulta</h3>
              <form onSubmit={handleCreate} className="space-y-4">
                <select
                  value={formData.patientId}
                  onChange={(e) => setFormData({...formData, patientId: e.target.value})}
                  className="input-field"
                  required
                >
                  <option value="">Selecione a paciente</option>
                  {patients.map(p => (
                    <option key={p.objectId} value={p.objectId}>
                      {p.objectData.name}
                    </option>
                  ))}
                </select>
                <input
                  type="datetime-local"
                  value={formData.date}
                  onChange={(e) => setFormData({...formData, date: e.target.value})}
                  className="input-field"
                  required
                />
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({...formData, type: e.target.value})}
                  className="input-field"
                >
                  <option value="Consulta Pré-Natal">Consulta Pré-Natal</option>
                  <option value="Ultrassom">Ultrassom</option>
                  <option value="Exames Laboratoriais">Exames Laboratoriais</option>
                  <option value="Vacinas">Vacinas</option>
                </select>
                <textarea
                  placeholder="Observações (opcional)"
                  value={formData.notes}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  className="input-field"
                  rows="3"
                ></textarea>
                <div className="flex space-x-4">
                  <button type="submit" className="btn-primary flex-1">Agendar</button>
                  <button type="button" onClick={() => setShowModal(false)} className="btn-secondary flex-1">Cancelar</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('AppointmentManager error:', error);
    return null;
  }
}

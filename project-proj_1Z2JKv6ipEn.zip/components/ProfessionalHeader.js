function ProfessionalHeader({ currentView, onViewChange }) {
  try {
    const user = getCurrentUser();
    const [unreadCount, setUnreadCount] = React.useState(0);

    React.useEffect(() => {
      loadUnreadCount();
      const interval = setInterval(loadUnreadCount, 30000);
      return () => clearInterval(interval);
    }, []);

    const loadUnreadCount = async () => {
      try {
        if (!user || !user.id) return;
        const result = await trickleListObjects('notification', 100, true);
        if (result && result.items) {
          const unread = result.items.filter(n => 
            n.objectData && n.objectData.userId === user.id && !n.objectData.read
          ).length;
          setUnreadCount(unread);
        }
      } catch (error) {
        console.error('Error loading unread count:', error);
        setUnreadCount(0);
      }
    };

    return (
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button onClick={() => onViewChange('dashboard')} className="flex items-center space-x-3 hover:opacity-80 transition-opacity">
              <div className="w-12 h-12 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
                <div className="icon-heart text-2xl text-white"></div>
              </div>
              <span className="text-2xl font-bold text-[var(--text-dark)]">Maternia</span>
            </button>
            <div className="flex items-center space-x-6">
              <button 
                onClick={() => onViewChange('notifications')}
                className="relative p-2 hover:bg-gray-100 rounded-lg transition-colors"
                title="Notificações"
              >
                <div className="icon-bell text-xl text-gray-700"></div>
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </button>
              <button onClick={() => onViewChange('password')} className="flex items-center space-x-3 hover:opacity-80 transition-opacity">
                <div className="w-10 h-10 bg-gradient-to-br from-[var(--secondary-color)] to-blue-400 rounded-full flex items-center justify-center shadow-md">
                  <div className="icon-user text-lg text-white"></div>
                </div>
                <span className="text-sm font-medium text-[var(--text-dark)]">{user?.name}</span>
              </button>
              <button onClick={logout} className="px-6 py-2.5 bg-[var(--accent-color)] text-[var(--primary-color)] rounded-full font-medium hover:bg-[#FFE5EC] transition-colors">
                Sair
              </button>
            </div>
          </div>
        </div>
      </header>
    );
  } catch (error) {
    console.error('ProfessionalHeader error:', error);
    return null;
  }
}

function SystemLogs({ setAlert, onViewChange }) {
  try {
    const [logs, setLogs] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [filter, setFilter] = React.useState('all');
    const [searchTerm, setSearchTerm] = React.useState('');

    React.useEffect(() => {
      loadLogs();
    }, []);

    const loadLogs = async () => {
      try {
        const result = await trickleListObjects('system_log', 200, true);
        if (result && result.items) {
          setLogs(result.items);
        } else {
          setLogs([]);
        }
      } catch (error) {
        console.error('Error loading logs:', error);
        setAlert({ type: 'error', message: 'Erro ao carregar logs' });
      } finally {
        setLoading(false);
      }
    };

    const getActionIcon = (action) => {
      const iconMap = {
        'login': 'log-in',
        'logout': 'log-out',
        'create': 'plus-circle',
        'update': 'edit',
        'delete': 'trash-2',
        'view': 'eye',
        'export': 'download',
        'import': 'upload'
      };
      return iconMap[action] || 'activity';
    };

    const getActionColor = (action) => {
      const colorMap = {
        'login': 'text-blue-600 bg-blue-100',
        'logout': 'text-gray-600 bg-gray-100',
        'create': 'text-green-600 bg-green-100',
        'update': 'text-yellow-600 bg-yellow-100',
        'delete': 'text-red-600 bg-red-100',
        'view': 'text-purple-600 bg-purple-100'
      };
      return colorMap[action] || 'text-gray-600 bg-gray-100';
    };

    const filteredLogs = logs.filter(log => {
      const matchesFilter = filter === 'all' || log.objectData.action === filter;
      const matchesSearch = !searchTerm || 
        log.objectData.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.objectData.description.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesFilter && matchesSearch;
    });

    if (loading) {
      return <div className="text-center py-8">Carregando logs...</div>;
    }

    return (
      <div>
        <button onClick={() => onViewChange('dashboard')} className="btn btn-secondary mb-4">
          <div className="icon-arrow-left text-lg"></div>
          Voltar ao Painel
        </button>
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Logs do Sistema</h2>
          
          <div className="card">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <input
                  type="text"
                  placeholder="Pesquisar por usuário ou ação..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="input"
                />
              </div>
              
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="input md:w-48"
              >
                <option value="all">Todas as ações</option>
                <option value="login">Login</option>
                <option value="logout">Logout</option>
                <option value="create">Criar</option>
                <option value="update">Atualizar</option>
                <option value="delete">Excluir</option>
                <option value="view">Visualizar</option>
              </select>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {filteredLogs.length === 0 ? (
            <div className="card text-center py-8">
              <div className="icon-activity text-4xl text-gray-300 mb-3"></div>
              <p className="text-gray-500">Nenhum log encontrado</p>
            </div>
          ) : (
            filteredLogs.map(log => (
              <div key={log.objectId} className="card animate-slide-in hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4 flex-1">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="icon-user text-lg text-gray-600"></div>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="font-semibold text-gray-900">{log.objectData.userName}</h3>
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${getActionColor(log.objectData.action)}`}>
                          <div className={`icon-${getActionIcon(log.objectData.action)} text-sm mr-1`}></div>
                          {log.objectData.action}
                        </span>
                      </div>
                      
                      <p className="text-sm text-gray-600 mb-2">{log.objectData.description}</p>
                      
                      <div className="flex flex-wrap items-center gap-2 sm:gap-4 text-xs text-gray-500">
                        <span className="flex items-center">
                          <div className="icon-clock text-sm mr-1"></div>
                          {new Date(log.createdAt).toLocaleString('pt-PT')}
                        </span>
                        <span className="flex items-center">
                          <div className="icon-shield text-sm mr-1"></div>
                          {log.objectData.userRole}
                        </span>
                        <span className="flex items-center">
                          <div className="icon-globe text-sm mr-1"></div>
                          {log.objectData.ipAddress || 'N/A'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('SystemLogs error:', error);
    return null;
  }
}
function Dashboard({ setAlert, onViewChange }) {
  try {
    const currentUser = getCurrentUser();

    return (
      <div className="space-y-6 pb-24 md:pb-6">
        <div className="bg-gradient-to-br from-[var(--accent-color)] to-white border border-gray-100 rounded-3xl shadow-sm p-6 md:p-8">
          <h1 className="text-2xl md:text-3xl font-bold text-[var(--text-dark)] mb-3">Bem-vinda ao Maternia</h1>
          <p className="text-sm text-gray-600 leading-relaxed">
            Este painel permite acompanhar sua gestação, realizar autoavaliações, 
            conversar com seu profissional de saúde e acessar conteúdo educativo sobre pré-natal.
          </p>
        </div>

        <div className="hidden md:grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-2">
          <div className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 p-6 border border-pink-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-[var(--text-dark)] mb-2 uppercase tracking-wide">Próxima Consulta</p>
                <p className="text-2xl font-bold text-[var(--primary-color)]">15 Nov 2025</p>
              </div>
              <div className="w-14 h-14 bg-[var(--primary-color)] rounded-xl flex items-center justify-center shadow-lg">
                <div className="icon-calendar text-xl text-white"></div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 p-6 border border-pink-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-[var(--text-dark)] mb-2 uppercase tracking-wide">Semanas</p>
                <p className="text-2xl font-bold text-[var(--primary-color)]">24 semanas</p>
              </div>
              <div className="w-14 h-14 bg-[var(--secondary-color)] rounded-xl flex items-center justify-center shadow-lg">
                <div className="icon-heart-pulse text-xl text-white"></div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 p-6 border border-pink-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-[var(--text-dark)] mb-2 uppercase tracking-wide">Exames</p>
                <p className="text-2xl font-bold text-[var(--primary-color)]">8 realizados</p>
              </div>
              <div className="w-14 h-14 bg-[var(--primary-color)] rounded-xl flex items-center justify-center shadow-lg">
                <div className="icon-clipboard-check text-xl text-white"></div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <button onClick={() => onViewChange('assessment')} className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 animate-slide-in text-left border border-pink-100">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
                <div className="icon-activity text-base text-white"></div>
              </div>
              <h3 className="text-lg font-bold text-gray-900">Autoavaliação</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">Avaliar seus sintomas e receber orientações.</p>
          </button>

          <button onClick={() => onViewChange('appointments')} className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 animate-slide-in text-left border border-pink-100" style={{ animationDelay: '100ms' }}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-[var(--secondary-color)] rounded-full flex items-center justify-center">
                <div className="icon-calendar text-base text-white"></div>
              </div>
              <h3 className="text-lg font-bold text-gray-900">Minhas Consultas</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">Ver consultas agendadas e histórico.</p>
          </button>

          <button onClick={() => onViewChange('education')} className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 animate-slide-in text-left border border-pink-100" style={{ animationDelay: '200ms' }}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
                <div className="icon-book-open text-base text-white"></div>
              </div>
              <h3 className="text-lg font-bold text-gray-900">Conteúdo Educativo</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">Aprender sobre cuidados pré-natais.</p>
          </button>

          <button onClick={() => onViewChange('chat')} className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 animate-slide-in text-left border border-pink-100" style={{ animationDelay: '300ms' }}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-[var(--secondary-color)] rounded-full flex items-center justify-center">
                <div className="icon-message-circle text-base text-white"></div>
              </div>
              <h3 className="text-lg font-bold text-gray-900">Conversar</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">Conversar com seu profissional de saúde.</p>
          </button>
        </div>

        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 md:hidden z-50">
          <div className="grid grid-cols-4 gap-1 p-2">
            <button onClick={() => onViewChange('assessment')} className="flex flex-col items-center justify-center py-3 hover:bg-gray-50 rounded-lg transition-colors">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mb-1">
                <div className="icon-activity text-lg text-blue-600"></div>
              </div>
              <span className="text-xs font-medium text-gray-700">Avaliação</span>
            </button>

            <button onClick={() => onViewChange('appointments')} className="flex flex-col items-center justify-center py-3 hover:bg-gray-50 rounded-lg transition-colors">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mb-1">
                <div className="icon-calendar text-lg text-green-600"></div>
              </div>
              <span className="text-xs font-medium text-gray-700">Consultas</span>
            </button>

            <button onClick={() => onViewChange('education')} className="flex flex-col items-center justify-center py-3 hover:bg-gray-50 rounded-lg transition-colors">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mb-1">
                <div className="icon-book-open text-lg text-purple-600"></div>
              </div>
              <span className="text-xs font-medium text-gray-700">Educação</span>
            </button>

            <button onClick={() => onViewChange('chat')} className="flex flex-col items-center justify-center py-3 hover:bg-gray-50 rounded-lg transition-colors">
              <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center mb-1">
                <div className="icon-message-circle text-lg text-orange-600"></div>
              </div>
              <span className="text-xs font-medium text-gray-700">Chat</span>
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Dashboard error:', error);
    return null;
  }
}

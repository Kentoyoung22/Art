function AdminReports({ setAlert, onViewChange }) {
  try {
    const [loading, setLoading] = React.useState(false);
    const [stats, setStats] = React.useState({
      totalUsers: 0,
      totalProfessionals: 0,
      totalPatients: 0,
      totalAssessments: 0,
      totalAppointments: 0,
      totalLogs: 0
    });

    React.useEffect(() => {
      loadStats();
    }, []);

    const loadStats = async () => {
      setLoading(true);
      try {
        const users = await trickleListObjects('user', 1000, true);
        const assessments = await trickleListObjects('assessment', 1000, true);
        const appointments = await trickleListObjects('appointment', 1000, true);
        const logs = await trickleListObjects('system_log', 1000, true);

        setStats({
          totalUsers: users.items.length,
          totalProfessionals: users.items.filter(u => u.objectData.role === 'professional').length,
          totalPatients: users.items.filter(u => u.objectData.role === 'patient').length,
          totalAssessments: assessments.items.length,
          totalAppointments: appointments.items.length,
          totalLogs: logs.items.length
        });
      } catch (error) {
        console.error('Error loading stats:', error);
      } finally {
        setLoading(false);
      }
    };

    const exportReport = async () => {
      try {
        const users = await trickleListObjects('user', 1000, true);
        const assessments = await trickleListObjects('assessment', 1000, true);
        const appointments = await trickleListObjects('appointment', 1000, true);
        
        let csvContent = 'data:text/csv;charset=utf-8,';
        csvContent += 'Relatório do Sistema Pré-Natal\n';
        csvContent += `Data: ${new Date().toLocaleDateString('pt-PT')}\n\n`;
        csvContent += 'Tipo,Quantidade\n';
        csvContent += `Total de Usuários,${users.items.length}\n`;
        csvContent += `Profissionais,${users.items.filter(u => u.objectData.role === 'professional').length}\n`;
        csvContent += `Pacientes,${users.items.filter(u => u.objectData.role === 'patient').length}\n`;
        csvContent += `Avaliações,${assessments.items.length}\n`;
        csvContent += `Consultas,${appointments.items.length}\n\n`;
        
        csvContent += 'Usuários\n';
        csvContent += 'Nome,Email,Função,Status\n';
        users.items.forEach(u => {
          csvContent += `${u.objectData.name},${u.objectData.email},${u.objectData.role},${u.objectData.active ? 'Ativo' : 'Inativo'}\n`;
        });
        
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement('a');
        link.setAttribute('href', encodedUri);
        link.setAttribute('download', `relatorio-sistema-${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        setAlert({ type: 'success', message: 'Relatório exportado em Excel com sucesso' });
      } catch (error) {
        console.error('Error exporting report:', error);
        setAlert({ type: 'error', message: 'Erro ao exportar relatório' });
      }
    };

    return (
      <div>
        <button onClick={() => onViewChange('dashboard')} className="btn btn-secondary mb-4">
          <div className="icon-arrow-left text-lg"></div>
          Voltar ao Painel
        </button>

        <h2 className="text-2xl font-bold mb-6">Relatórios do Sistema</h2>

        {loading ? (
          <div className="text-center py-8">Carregando estatísticas...</div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
              <div className="card">
                <h3 className="font-semibold mb-2">Total de Usuários</h3>
                <p className="text-3xl font-bold text-[var(--primary-color)]">{stats.totalUsers}</p>
              </div>
              <div className="card">
                <h3 className="font-semibold mb-2">Profissionais</h3>
                <p className="text-3xl font-bold text-green-600">{stats.totalProfessionals}</p>
              </div>
              <div className="card">
                <h3 className="font-semibold mb-2">Pacientes</h3>
                <p className="text-3xl font-bold text-blue-600">{stats.totalPatients}</p>
              </div>
            </div>

            <button onClick={exportReport} className="btn btn-primary">
              <div className="icon-download text-lg"></div>
              Exportar Relatório
            </button>
          </>
        )}
      </div>
    );
  } catch (error) {
    console.error('AdminReports error:', error);
    return null;
  }
}
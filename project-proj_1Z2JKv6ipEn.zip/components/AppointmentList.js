function AppointmentList({ setAlert }) {
  try {
    const [appointments, setAppointments] = React.useState([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
      loadAppointments();
    }, []);

    const loadAppointments = async () => {
      try {
        const user = getCurrentUser();
        if (!user || !user.id) {
          setLoading(false);
          setAppointments([]);
          return;
        }
        
        let result;
        try {
          result = await trickleListObjects('appointment', 100, true);
        } catch (fetchError) {
          console.error('Database fetch error:', fetchError);
          setAppointments([]);
          setLoading(false);
          return;
        }
        
        if (result && result.items && Array.isArray(result.items)) {
          const userAppointments = result.items.filter(apt => 
            apt && apt.objectData && apt.objectData.patientId === user.id
          );
          setAppointments(userAppointments);
        } else {
          setAppointments([]);
        }
      } catch (error) {
        console.error('Error loading appointments:', error);
        setAppointments([]);
      } finally {
        setLoading(false);
      }
    };

    const getStatusColor = (status) => {
      switch(status) {
        case 'Agendada': return 'bg-yellow-100 text-yellow-800';
        case 'Confirmada': return 'bg-blue-100 text-blue-800';
        case 'Realizada': return 'bg-green-100 text-green-800';
        case 'Cancelada': return 'bg-red-100 text-red-800';
        default: return 'bg-gray-100 text-gray-800';
      }
    };

    const getStatusLabel = (apt) => {
      const appointmentDate = new Date(apt.objectData.date);
      const now = new Date();
      
      if (apt.objectData.status === 'Realizada') {
        return 'Concluída';
      }
      
      if (appointmentDate < now && apt.objectData.status !== 'Cancelada') {
        return 'Concluída';
      }
      
      switch(apt.objectData.status) {
        case 'Agendada': return 'Pendente';
        case 'Confirmada': return 'Confirmada';
        case 'Cancelada': return 'Cancelada';
        default: return apt.objectData.status;
      }
    };

    if (loading) {
      return <div className="text-center py-8">Carregando consultas...</div>;
    }

    return (
      <div className="pb-24 md:pb-0">
        <button onClick={() => window.location.href = 'patient.html'} className="btn-primary mb-4">
          <div className="flex items-center space-x-2">
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar ao Painel</span>
          </div>
        </button>
        <h2 className="text-2xl font-bold mb-6">Minhas Consultas</h2>
        
        <div className="space-y-4">
          {appointments.length === 0 ? (
            <div className="bg-white rounded-lg shadow p-8 text-center">
              <div className="icon-calendar text-4xl text-gray-300 mb-4"></div>
              <p className="text-gray-500">Nenhuma consulta agendada</p>
            </div>
          ) : (
            appointments.map(apt => (
              <div key={apt.objectId} className="bg-white rounded-lg shadow p-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <div className="icon-calendar text-xl text-blue-600"></div>
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">{apt.objectData.type}</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        {new Date(apt.objectData.date).toLocaleDateString('pt-PT', {
                          day: 'numeric',
                          month: 'long',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                      {apt.objectData.notes && (
                        <p className="text-sm text-gray-500 mt-2">{apt.objectData.notes}</p>
                      )}
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm ${getStatusColor(apt.objectData.status)}`}>
                    {getStatusLabel(apt)}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('AppointmentList error:', error);
    return null;
  }
}
function RiskMonitoring({ setAlert, onViewChange }) {
  try {
    const [patients, setPatients] = React.useState([]);
    const [assessments, setAssessments] = React.useState([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
      loadData();
    }, []);

    const loadData = async () => {
      try {
        const user = getCurrentUser();
        if (!user || !user.id) {
          setLoading(false);
          setPatients([]);
          setAssessments([]);
          return;
        }
        
        let patientsResult;
        let retries = 0;
        const maxRetries = 3;
        
        while (retries < maxRetries) {
          try {
            patientsResult = await trickleListObjects('user', 100, true);
            break;
          } catch (fetchError) {
            retries++;
            if (retries >= maxRetries) {
              setPatients([]);
              setAssessments([]);
              setLoading(false);
              return;
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
        }
        
        if (patientsResult && patientsResult.items && Array.isArray(patientsResult.items)) {
          const myPatients = patientsResult.items.filter(p => 
            p && p.objectData && p.objectData.role === 'patient' && p.objectData.professionalId === user.id
          );
          setPatients(myPatients);
          
          let assessResult;
          retries = 0;
          
          while (retries < maxRetries) {
            try {
              assessResult = await trickleListObjects('assessment', 100, true);
              break;
            } catch (fetchError) {
              retries++;
              if (retries >= maxRetries) {
                setAssessments([]);
                setLoading(false);
                return;
              }
              await new Promise(resolve => setTimeout(resolve, 1000));
            }
          }
          
          if (assessResult && assessResult.items && Array.isArray(assessResult.items)) {
            const relevantAssessments = assessResult.items.filter(a => 
              a && a.objectData && myPatients.some(p => p.objectId === a.objectData.patientId)
            ).map(a => {
              const patient = myPatients.find(p => p.objectId === a.objectData.patientId);
              return {
                ...a,
                patientName: patient && patient.objectData ? patient.objectData.name : 'Desconhecido'
              };
            });
            setAssessments(relevantAssessments);
          } else {
            setAssessments([]);
          }
        } else {
          setPatients([]);
          setAssessments([]);
        }
      } catch (error) {
        console.error('Error loading monitoring data:', error);
        setPatients([]);
        setAssessments([]);
      } finally {
        setLoading(false);
      }
    };

    const getRiskColor = (level) => {
      if (level === 'low') return 'bg-green-100 text-green-800';
      if (level === 'medium') return 'bg-yellow-100 text-yellow-800';
      return 'bg-red-100 text-red-800';
    };

    const highRiskPatients = assessments.filter(a => a.objectData.riskLevel === 'high');

    if (loading) {
      return <div className="text-center py-8">Carregando dados...</div>;
    }

    return (
      <div className="space-y-6">
        <button onClick={() => onViewChange('dashboard')} className="btn btn-primary mb-4">
          <div className="flex items-center space-x-2">
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar ao Painel</span>
          </div>
        </button>
        <h2 className="text-2xl font-bold">Monitoramento de Risco</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="bg-gradient-to-br from-pink-50 to-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 p-6 border border-pink-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-pink-700 mb-2 uppercase tracking-wide">Total Pacientes</p>
                <p className="text-4xl font-bold text-pink-600">{stats.totalPatients}</p>
              </div>
              <div className="w-16 h-16 bg-pink-500 rounded-2xl flex items-center justify-center shadow-lg">
                <div className="icon-users text-2xl text-white"></div>
              </div>
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-red-50 to-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 p-6 border border-red-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-red-700 mb-2 uppercase tracking-wide">Alto Risco</p>
                <p className="text-4xl font-bold text-red-600">{stats.highRisk}</p>
              </div>
              <div className="w-16 h-16 bg-red-500 rounded-2xl flex items-center justify-center shadow-lg">
                <div className="icon-alert-triangle text-2xl text-white"></div>
              </div>
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-pink-50 to-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 p-6 border border-pink-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-pink-700 mb-2 uppercase tracking-wide">Avaliações</p>
                <p className="text-4xl font-bold text-pink-600">{stats.totalAssessments}</p>
              </div>
              <div className="w-16 h-16 bg-pink-500 rounded-2xl flex items-center justify-center shadow-lg">
                <div className="icon-clipboard-check text-2xl text-white"></div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b">
            <h3 className="text-lg font-semibold">Avaliações Recentes</h3>
          </div>
          <div className="divide-y">
            {assessments.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                Nenhuma avaliação registrada
              </div>
            ) : (
              assessments.slice(0, 10).map(assessment => (
                <div key={assessment.objectId} className="p-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-semibold">{assessment.patientName}</h4>
                      <p className="text-sm text-gray-600 mt-1">{assessment.objectData.analysis}</p>
                      <p className="text-xs text-gray-400 mt-2">
                        {new Date(assessment.objectData.date).toLocaleDateString('pt-PT')}
                      </p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm ${getRiskColor(assessment.objectData.riskLevel)}`}>
                      {assessment.objectData.riskLevel === 'low' ? 'Baixo' : 
                       assessment.objectData.riskLevel === 'medium' ? 'Médio' : 'Alto'}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('RiskMonitoring error:', error);
    return null;
  }
}
function EducationalContent({ setAlert }) {
  try {
    const [topics] = React.useState([
      { 
        id: 1, 
        title: 'Nutrição na Gravidez', 
        icon: 'apple',
        image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=800&q=80'
      },
      { 
        id: 2, 
        title: 'Exercícios Seguros', 
        icon: 'activity',
        image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=800&q=80'
      },
      { 
        id: 3, 
        title: 'Sinais de Alerta', 
        icon: 'alert-circle',
        image: 'https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?w=800&q=80'
      },
      { 
        id: 4, 
        title: 'Preparação para o Parto', 
        icon: 'baby',
        image: 'https://images.unsplash.com/photo-1584515933487-779824d29309?w=800&q=80'
      },
      { 
        id: 5, 
        title: 'Cuidados Pós-Parto', 
        icon: 'heart',
        image: 'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?w=800&q=80'
      },
      { 
        id: 6, 
        title: 'Amamentação', 
        icon: 'droplet',
        image: 'https://images.unsplash.com/photo-1476703993599-0035a21b17a9?w=800&q=80'
      }
    ]);
    const [selectedTopic, setSelectedTopic] = React.useState(null);
    const [content, setContent] = React.useState('');
    const [loading, setLoading] = React.useState(false);
    const [progress, setProgress] = React.useState(0);

    const loadContent = async (topic) => {
      setSelectedTopic(topic);
      setProgress(0);
      setLoading(true);
      
      const progressInterval = setInterval(() => {
        setProgress(prev => Math.min(prev + 15, 90));
      }, 200);
      
      try {
        if (typeof generateEducationalContent === 'undefined') {
          clearInterval(progressInterval);
          setAlert({ type: 'error', message: 'Sistema ainda carregando. Aguarde alguns segundos e tente novamente.' });
          setLoading(false);
          setSelectedTopic(null);
          return;
        }
        let contentPrompt = '';
        if (topic.title === 'Exercícios Seguros') {
          contentPrompt = `Crie um guia completo e acolhedor sobre exercícios seguros durante a gravidez para gestantes em Moçambique. 

O conteúdo deve incluir:

1. INTRODUÇÃO RECONFORTANTE
- Explique a importância de manter-se ativa durante a gravidez
- Tranquilize sobre os benefícios para mãe e bebê
- Use tom caloroso e encorajador

2. BENEFÍCIOS DOS EXERCÍCIOS NA GRAVIDEZ
- Melhora da circulação sanguínea
- Redução de dores nas costas
- Controle do ganho de peso
- Melhora do humor e redução do estresse
- Preparação para o parto
- Recuperação pós-parto mais rápida

3. EXERCÍCIOS RECOMENDADOS POR TRIMESTRE

PRIMEIRO TRIMESTRE (1-12 semanas):
- Caminhadas leves (20-30 minutos por dia)
- Alongamentos suaves
- Yoga pré-natal para iniciantes
- Natação leve
- Exercícios pélvicos (Kegel)

SEGUNDO TRIMESTRE (13-26 semanas):
- Caminhadas (30-40 minutos)
- Yoga pré-natal moderada
- Natação
- Hidroginástica
- Bicicleta ergométrica leve
- Exercícios com bola suíça

TERCEIRO TRIMESTRE (27-40 semanas):
- Caminhadas suaves (20-30 minutos)
- Alongamentos e respiração
- Exercícios na água
- Yoga restaurativa
- Preparação do períneo

4. COMO FAZER CADA EXERCÍCIO (INSTRUÇÕES DETALHADAS)
- Descreva passo a passo como realizar
- Posição inicial, movimento e finalização
- Respiração adequada
- Número de repetições recomendado

5. SINAIS DE ALERTA - QUANDO PARAR
- Sangramento vaginal
- Tontura ou falta de ar intensa
- Dor no peito
- Dor de cabeça forte
- Contrações regulares
- Diminuição dos movimentos do bebê
- Dor nas panturrilhas

6. DICAS PRÁTICAS
- Melhor horário para exercitar (evite calor intenso)
- Hidratação adequada
- Roupas confortáveis
- Importância do aquecimento e resfriamento
- Como adaptar exercícios ao contexto africano

7. CONTRAINDICAÇÕES
- Quando NÃO fazer exercícios
- Condições que requerem repouso

Use linguagem simples, calorosa e acessível. Seja detalhado e prático.`;
        } else {
          contentPrompt = `Crie um artigo educativo sobre "${topic.title}" para gestantes em Moçambique. Inclua informações práticas, recomendações baseadas em evidências e dicas específicas para o contexto africano.`;
        }
        
        const generatedContent = await generateEducationalContent(contentPrompt);
        clearInterval(progressInterval);
        setProgress(100);
        setContent(generatedContent);
      } catch (error) {
        clearInterval(progressInterval);
        setAlert({ type: 'error', message: 'Erro ao carregar conteúdo' });
      } finally {
        setLoading(false);
      }
    };

    return (
      <div className="pb-24 md:pb-0">
        <button onClick={() => window.location.href = 'patient.html'} className="btn-primary mb-4">
          <div className="flex items-center space-x-2">
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar ao Painel</span>
          </div>
        </button>
        <h2 className="text-xl md:text-2xl font-bold mb-4 md:mb-6">Conteúdo Educativo</h2>
        
        {!selectedTopic ? (
          <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
            {topics.map(topic => (
              <button
                key={topic.id}
                onClick={() => loadContent(topic)}
                className="bg-white rounded-lg md:rounded-xl shadow-md overflow-hidden text-left hover:shadow-xl transition-all transform hover:scale-105"
              >
                <div className="relative h-32 md:h-40 overflow-hidden">
                  <img 
                    src={topic.image} 
                    alt={topic.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute bottom-2 left-2 md:bottom-3 md:left-3 w-8 h-8 md:w-10 md:h-10 bg-white rounded-lg flex items-center justify-center shadow-lg">
                    <div className={`icon-${topic.icon} text-base md:text-lg text-pink-600`}></div>
                  </div>
                </div>
                <div className="p-3 md:p-4">
                  <h3 className="font-semibold text-sm md:text-lg">{topic.title}</h3>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow p-4 md:p-6">
            <button
              onClick={() => setSelectedTopic(null)}
              className="flex items-center space-x-2 text-[var(--primary-color)] mb-4 hover:underline"
            >
              <div className="icon-arrow-left text-lg"></div>
              <span>Voltar</span>
            </button>
            
            <div className="relative h-48 md:h-64 rounded-xl overflow-hidden mb-4 md:mb-6">
              <img 
                src={selectedTopic.image} 
                alt={selectedTopic.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent flex items-end">
                <h3 className="text-xl md:text-3xl font-bold text-white p-4 md:p-6">{selectedTopic.title}</h3>
              </div>
            </div>
            
            {loading ? (
              <div className="text-center py-12">
                <div className="relative w-full max-w-md mx-auto mb-6">
                  <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-[var(--primary-color)] to-pink-400 rounded-full transition-all duration-300 ease-out"
                      style={{ width: `${progress}%` }}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">{progress}%</p>
                </div>
                <div className="inline-block animate-pulse mb-4">
                  <div className="w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center">
                    <div className="icon-book-open text-3xl text-pink-600"></div>
                  </div>
                </div>
                <p className="text-lg font-medium text-gray-700">Preparando conteúdo...</p>
                <p className="text-sm text-gray-500 mt-2">Gerando informações personalizadas</p>
              </div>
            ) : (
              <div className="prose max-w-none">
                <p className="whitespace-pre-wrap text-gray-700">{content}</p>
              </div>
            )}
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('EducationalContent error:', error);
    return null;
  }
}
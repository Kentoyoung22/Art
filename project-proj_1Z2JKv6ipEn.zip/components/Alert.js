function Alert({ type, message, onClose }) {
  try {
    const bgColor = type === 'error' ? 'bg-red-100 border-red-500' : 'bg-pink-100 border-pink-500';
    const textColor = type === 'error' ? 'text-red-800' : 'text-pink-800';
    const icon = type === 'error' ? 'alert-circle' : 'check-circle';

    return (
      <div className={`fixed top-4 right-4 z-50 ${bgColor} border-l-4 p-4 rounded-lg shadow-lg max-w-md`}>
        <div className="flex items-start">
          <div className={`icon-${icon} text-xl ${textColor} mr-3 mt-0.5`}></div>
          <div className="flex-1">
            <p className={`${textColor} font-medium`}>{message}</p>
          </div>
          <button onClick={onClose} className={`${textColor} hover:opacity-70 ml-3`}>
            <div className="icon-x text-lg"></div>
          </button>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Alert error:', error);
    return null;
  }
}

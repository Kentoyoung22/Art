function PasswordChange({ setAlert }) {
  try {
    const [currentPassword, setCurrentPassword] = React.useState('');
    const [newPassword, setNewPassword] = React.useState('');
    const [confirmPassword, setConfirmPassword] = React.useState('');
    const [loading, setLoading] = React.useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (newPassword !== confirmPassword) {
      setAlert({ type: 'error', message: 'As senhas não coincidem' });
      return;
    }

    if (newPassword.length < 6) {
      setAlert({ type: 'error', message: 'A senha deve ter pelo menos 6 caracteres' });
      return;
    }

    setLoading(true);

    try {
      const user = getCurrentUser();
      if (!user || !user.id) {
        setAlert({ type: 'error', message: 'Sessão expirada. Faça login novamente.' });
        setLoading(false);
        return;
      }

      const usersResult = await trickleListObjects('user', 100, true);
      const currentUserData = usersResult.items.find(u => u.objectId === user.id);

      if (!currentUserData) {
        setAlert({ type: 'error', message: 'Usuário não encontrado' });
        setLoading(false);
        return;
      }

      if (currentUserData.objectData.password !== currentPassword) {
        setAlert({ type: 'error', message: 'Senha atual incorreta' });
        setLoading(false);
        return;
      }

      await trickleUpdateObject('user', user.id, {
        ...currentUserData.objectData,
        password: newPassword
      });

      try {
        await trickleCreateObject('system_log', {
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          action: 'update',
          description: `${user.name} alterou a senha`,
          ipAddress: 'N/A',
          timestamp: new Date().toISOString()
        });
      } catch (logError) {
        console.error('Log error:', logError);
      }

      setAlert({ type: 'success', message: 'Senha alterada com sucesso! Use a nova senha no próximo login.' });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (error) {
      console.error('Error changing password:', error);
      setAlert({ type: 'error', message: 'Erro ao alterar senha. Tente novamente.' });
    } finally {
      setLoading(false);
    }
  };

    return (
      <div className="max-w-lg mx-auto">
        <button onClick={() => {
          const user = getCurrentUser();
          if (user.role === 'admin') window.location.href = 'admin.html';
          else if (user.role === 'professional') window.location.href = 'professional.html';
          else window.location.href = 'patient.html';
        }} className="btn-primary mb-6">
          <div className="flex items-center space-x-2">
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar ao Painel</span>
          </div>
        </button>
        <div className="bg-gradient-to-br from-[#FFF5F7] to-white rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-white bg-opacity-90 backdrop-blur-sm p-8 md:p-10">
            <div className="flex items-center justify-center w-20 h-20 bg-gradient-to-br from-[var(--primary-color)] to-pink-500 rounded-2xl mx-auto mb-6 shadow-lg">
              <div className="icon-lock text-3xl text-white"></div>
            </div>
            <h2 className="text-3xl font-bold text-center mb-3 text-gray-900">Alterar Senha</h2>
            <p className="text-center text-gray-600 mb-8 text-base">Atualize sua senha de acesso ao sistema</p>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="block text-sm font-bold text-gray-800 mb-2 flex items-center">
                  <div className="icon-key text-base text-[var(--primary-color)] mr-2"></div>
                  Senha Atual
                </label>
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent transition-all text-base"
                  placeholder="Digite sua senha atual"
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-bold text-gray-800 mb-2 flex items-center">
                  <div className="icon-lock text-base text-[var(--primary-color)] mr-2"></div>
                  Nova Senha
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent transition-all text-base"
                  placeholder="Digite a nova senha"
                  required
                />
                <div className="flex items-start mt-2">
                  <div className="icon-info text-sm text-[var(--primary-color)] mr-2 mt-0.5"></div>
                  <p className="text-xs text-gray-600">Mínimo de 6 caracteres</p>
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-bold text-gray-800 mb-2 flex items-center">
                  <div className="icon-check-circle text-base text-[var(--primary-color)] mr-2"></div>
                  Confirmar Nova Senha
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent transition-all text-base"
                  placeholder="Confirme a nova senha"
                  required
                />
              </div>

              <button type="submit" className="w-full py-4 bg-gradient-to-r from-[var(--primary-color)] to-pink-500 text-white rounded-xl font-bold text-base hover:opacity-90 transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed mt-8" disabled={loading}>
                {loading ? (
                  <span className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent mr-2"></div>
                    Alterando...
                  </span>
                ) : (
                  <span className="flex items-center justify-center">
                    <div className="icon-shield-check text-xl mr-2"></div>
                    Alterar Senha
                  </span>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('PasswordChange error:', error);
    return null;
  }
}

function PatientManagement({ setAlert, onViewChange }) {
  try {
    const [patients, setPatients] = React.useState([]);
    const [showModal, setShowModal] = React.useState(false);
    const [formData, setFormData] = React.useState({ name: '', email: '', password: '' });
    const currentUser = getCurrentUser();

    React.useEffect(() => {
      loadPatients();
    }, []);

    const loadPatients = async () => {
      try {
        const user = getCurrentUser();
        if (!user || !user.id) {
          console.log('No user found in loadPatients');
          setPatients([]);
          return;
        }
        
        if (typeof trickleListObjects === 'undefined') {
          setPatients([]);
          return;
        }
        
        let result;
        let retries = 0;
        const maxRetries = 3;
        
        while (retries < maxRetries) {
          try {
            result = await trickleListObjects('user', 100, true);
            break;
          } catch (fetchError) {
            retries++;
            if (retries >= maxRetries) {
              setPatients([]);
              return;
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
        }
        
        if (result && result.items && Array.isArray(result.items)) {
          const myPatients = result.items.filter(u => 
            u && u.objectData && u.objectData.role === 'patient' && u.objectData.professionalId === user.id
          );
          setPatients(myPatients);
        } else {
          setPatients([]);
        }
      } catch (error) {
        console.error('Error loading patients:', error);
        setPatients([]);
      }
    };

    const handleCreate = async (e) => {
      e.preventDefault();
      try {
        const professional = getCurrentUser();
        if (!professional || !professional.id) {
          setAlert({ type: 'error', message: 'Sessão expirada. Faça login novamente.' });
          return;
        }
        
        await trickleCreateObject('user', {
          name: formData.name,
          email: formData.email,
          password: formData.password,
          role: 'patient',
          professionalId: professional.id,
          active: true
        });
        
        setAlert({ type: 'success', message: 'Paciente cadastrado' });
        setShowModal(false);
        setFormData({ name: '', email: '', password: '' });
        loadPatients();
      } catch (error) {
        console.error('Error creating patient:', error);
        setAlert({ type: 'error', message: 'Erro ao cadastrar paciente' });
      }
    };

    return (
      <div>
        <button onClick={() => onViewChange('dashboard')} className="btn btn-primary mb-4">
          <div className="flex items-center space-x-2">
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar ao Painel</span>
          </div>
        </button>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <h2 className="text-2xl font-bold">Meus Pacientes</h2>
          <div className="flex flex-wrap gap-3 w-full sm:w-auto">
            <button onClick={() => onViewChange('reports')} className="btn-primary">
              <div className="flex items-center space-x-2">
                <div className="icon-chart-bar text-lg"></div>
                <span>Relatórios</span>
              </div>
            </button>
            <button onClick={() => setShowModal(true)} className="btn-primary">
              <div className="flex items-center space-x-2">
                <div className="icon-plus text-lg"></div>
                <span>Novo Paciente</span>
              </div>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {patients.length === 0 ? (
            <div className="col-span-full bg-white rounded-lg shadow p-8 text-center">
              <div className="icon-users text-4xl text-gray-300 mb-4"></div>
              <p className="text-gray-500">Nenhum paciente cadastrado</p>
            </div>
          ) : (
            patients.map(patient => (
              <div key={patient.objectId} className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center">
                  <div className="icon-user text-xl text-[var(--primary-color)]"></div>
                </div>
                  <div>
                    <h3 className="font-semibold">{patient.objectData.name}</h3>
                    <p className="text-sm text-gray-500">{patient.objectData.email}</p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {showModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-8 max-w-md w-full">
              <h3 className="text-xl font-bold mb-4">Novo Paciente</h3>
              <form onSubmit={handleCreate} className="space-y-4">
                <input type="text" placeholder="Nome" value={formData.name} 
                  onChange={(e) => setFormData({...formData, name: e.target.value})} 
                  className="input-field" required />
                <input type="email" placeholder="Email" value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="input-field" required />
                <input type="password" placeholder="Senha" value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  className="input-field" required />
                <div className="flex space-x-4">
                  <button type="submit" className="btn-primary flex-1">Cadastrar</button>
                  <button type="button" onClick={() => setShowModal(false)} className="btn-secondary flex-1">Cancelar</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('PatientManagement error:', error);
    return null;
  }
}
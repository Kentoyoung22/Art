function ProfessionalReports({ setAlert, onViewChange }) {
  try {
    const [stats, setStats] = React.useState({
      totalPatients: 0,
      highRisk: 0,
      appointments: 0
    });

    React.useEffect(() => {
      loadStats();
    }, []);

    const loadStats = async () => {
      try {
        const user = getCurrentUser();
        const patients = await trickleListObjects('user', 100, true);
        const myPatients = patients.items.filter(p => p.objectData.professionalId === user.id);
        
        const assessments = await trickleListObjects('assessment', 100, true);
        const highRiskCount = assessments.items.filter(a => 
          a.objectData.riskLevel === 'high' && 
          myPatients.some(p => p.objectId === a.objectData.patientId)
        ).length;

        const appointments = await trickleListObjects('appointment', 100, true);
        const myAppointments = appointments.items.filter(a => a.objectData.professionalId === user.id);

        setStats({
          totalPatients: myPatients.length,
          highRisk: highRiskCount,
          appointments: myAppointments.length
        });
      } catch (error) {
        console.error('Error loading stats:', error);
      }
    };

    const exportReport = async () => {
      try {
        const user = getCurrentUser();
        const patients = await trickleListObjects('user', 1000, true);
        const myPatients = patients.items.filter(p => p.objectData.professionalId === user.id);
        
        const assessments = await trickleListObjects('assessment', 1000, true);
        const appointments = await trickleListObjects('appointment', 1000, true);
        
        let csvContent = 'data:text/csv;charset=utf-8,';
        csvContent += 'Relatório - Minhas Pacientes\n';
        csvContent += `Profissional: ${user.name}\n`;
        csvContent += `Data: ${new Date().toLocaleDateString('pt-PT')}\n\n`;
        
        csvContent += 'Resumo\n';
        csvContent += 'Categoria,Quantidade\n';
        csvContent += `Total de Pacientes,${stats.totalPatients}\n`;
        csvContent += `Pacientes Alto Risco,${stats.highRisk}\n`;
        csvContent += `Consultas Agendadas,${stats.appointments}\n\n`;
        
        csvContent += 'Lista de Pacientes\n';
        csvContent += 'Nome,Email,Data Cadastro\n';
        myPatients.forEach(p => {
          csvContent += `${p.objectData.name},${p.objectData.email},${new Date(p.createdAt).toLocaleDateString('pt-PT')}\n`;
        });
        
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement('a');
        link.setAttribute('href', encodedUri);
        link.setAttribute('download', `relatorio-pacientes-${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        setAlert({ type: 'success', message: 'Relatório exportado em Excel' });
      } catch (error) {
        console.error('Error exporting report:', error);
        setAlert({ type: 'error', message: 'Erro ao exportar relatório' });
      }
    };

    return (
      <div>
        <button onClick={() => onViewChange('patients')} className="btn btn-secondary mb-4">
          <div className="icon-arrow-left text-lg"></div>
          Voltar
        </button>

        <h2 className="text-2xl font-bold mb-6">Relatórios</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          <div className="card">
            <h3 className="font-semibold mb-2">Total de Pacientes</h3>
            <p className="text-3xl font-bold text-[var(--primary-color)]">{stats.totalPatients}</p>
          </div>
          <div className="card">
            <h3 className="font-semibold mb-2">Alto Risco</h3>
            <p className="text-3xl font-bold text-red-600">{stats.highRisk}</p>
          </div>
          <div className="card">
            <h3 className="font-semibold mb-2">Consultas</h3>
            <p className="text-3xl font-bold text-green-600">{stats.appointments}</p>
          </div>
        </div>

        <button onClick={exportReport} className="btn btn-primary">
          <div className="icon-download text-lg"></div>
          Exportar Relatório
        </button>
      </div>
    );
  } catch (error) {
    console.error('ProfessionalReports error:', error);
    return null;
  }
}
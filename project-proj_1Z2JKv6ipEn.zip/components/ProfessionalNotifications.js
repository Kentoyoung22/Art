function ProfessionalNotifications({ setAlert, onViewChange }) {
  try {
    const [notifications, setNotifications] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [replyingTo, setReplyingTo] = React.useState(null);
    const [replyMessage, setReplyMessage] = React.useState('');
    const [sending, setSending] = React.useState(false);

    React.useEffect(() => {
      loadNotifications();
    }, []);

    const loadNotifications = async () => {
      try {
        const user = getCurrentUser();
        if (!user || !user.id) {
          setLoading(false);
          return;
        }
        
        const result = await trickleListObjects('notification', 100, true);
        if (result && result.items) {
          const userNotifications = result.items.filter(n => 
            n.objectData && n.objectData.userId === user.id
          );
          setNotifications(userNotifications);
        }
      } catch (error) {
        console.error('Error loading notifications:', error);
      } finally {
        setLoading(false);
      }
    };

    const markAsRead = async (notification) => {
      try {
        await trickleUpdateObject('notification', notification.objectId, {
          ...notification.objectData,
          read: true
        });
        loadNotifications();
      } catch (error) {
        console.error('Error marking as read:', error);
      }
    };

    const handleReply = async (notification) => {
      if (!replyMessage.trim()) return;
      
      setSending(true);
      try {
        const user = getCurrentUser();
        
        await trickleCreateObject('message', {
          senderId: user.id,
          senderName: user.name,
          receiverId: notification.objectData.messageId,
          content: replyMessage,
          read: false,
          createdAt: new Date().toISOString()
        });
        
        setAlert({ type: 'success', message: 'Resposta enviada' });
        setReplyingTo(null);
        setReplyMessage('');
      } catch (error) {
        console.error('Error sending reply:', error);
        setAlert({ type: 'error', message: 'Erro ao enviar resposta' });
      } finally {
        setSending(false);
      }
    };

    if (loading) {
      return <div className="text-center py-8">Carregando...</div>;
    }

    return (
      <div>
        <button onClick={() => onViewChange('dashboard')} className="btn btn-primary mb-4">
          <div className="flex items-center space-x-2">
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar ao Painel</span>
          </div>
        </button>
        <h2 className="text-2xl font-bold mb-6">Notificações</h2>
        
        <div className="space-y-4">
          {notifications.length === 0 ? (
            <div className="bg-white rounded-lg shadow p-8 text-center">
              <div className="icon-bell text-4xl text-gray-300 mb-4"></div>
              <p className="text-gray-500">Nenhuma notificação</p>
            </div>
          ) : (
            notifications.map(notif => (
              <div key={notif.objectId} className={`bg-white rounded-lg shadow p-6 ${!notif.objectData.read ? 'border-l-4 border-[var(--primary-color)]' : ''}`}>
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg">{notif.objectData.title}</h3>
                    <p className="text-gray-600 mt-2">{notif.objectData.message}</p>
                    <p className="text-xs text-gray-400 mt-2">
                      {new Date(notif.createdAt).toLocaleDateString('pt-PT', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                  </div>
                  {!notif.objectData.read && (
                    <button onClick={() => markAsRead(notif)} className="text-sm text-[var(--primary-color)] hover:underline ml-4">
                      Marcar como lida
                    </button>
                  )}
                </div>
                
                {notif.objectData.type === 'message' && notif.objectData.messageId && (
                  <div className="mt-4 pt-4 border-t">
                    <button onClick={() => onViewChange('chat')} className="btn-primary">
                      <div className="icon-message-circle text-lg"></div>
                      Ir às Conversas
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('ProfessionalNotifications error:', error);
    return null;
  }
}
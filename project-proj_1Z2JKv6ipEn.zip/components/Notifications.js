function Notifications({ setAlert }) {
  try {
    const [notifications, setNotifications] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [replyingTo, setReplyingTo] = React.useState(null);
    const [replyMessage, setReplyMessage] = React.useState('');
    const [sending, setSending] = React.useState(false);

    React.useEffect(() => {
      loadNotifications();
    }, []);

    const loadNotifications = async () => {
      try {
        const user = getCurrentUser();
        if (!user || !user.id) {
          setLoading(false);
          setNotifications([]);
          return;
        }
        
        let result;
        try {
          result = await trickleListObjects('notification', 100, true);
        } catch (fetchError) {
          console.error('Database fetch error:', fetchError);
          setNotifications([]);
          setLoading(false);
          return;
        }
        
        if (result && result.items && Array.isArray(result.items)) {
          const userNotifications = result.items.filter(notif => 
            notif && notif.objectData && notif.objectData.userId === user.id
          );
          setNotifications(userNotifications.slice(0, 50));
        } else {
          setNotifications([]);
        }
      } catch (error) {
        console.error('Error loading notifications:', error);
        setNotifications([]);
      } finally {
        setLoading(false);
      }
    };

    const markAsRead = async (notification) => {
      try {
        await trickleUpdateObject('notification', notification.objectId, {
          ...notification.objectData,
          read: true
        });
        loadNotifications();
      } catch (error) {
        console.error('Error marking notification as read:', error);
      }
    };

    const handleReply = async () => {
      if (!replyMessage.trim() || !replyingTo) return;
      
      setSending(true);
      try {
        const user = getCurrentUser();
        
        await trickleCreateObject('message', {
          senderId: user.id,
          senderName: user.name,
          receiverId: replyingTo.objectData.messageId,
          content: replyMessage,
          read: false,
          createdAt: new Date().toISOString()
        });
        
        await trickleCreateObject('notification', {
          userId: replyingTo.objectData.messageId,
          title: 'Nova Resposta',
          message: `${user.name} respondeu: "${replyMessage.substring(0, 50)}${replyMessage.length > 50 ? '...' : ''}"`,
          type: 'message',
          read: false,
          createdAt: new Date().toISOString()
        });
        
        setAlert({ type: 'success', message: 'Resposta enviada com sucesso' });
        setReplyingTo(null);
        setReplyMessage('');
        loadNotifications();
      } catch (error) {
        console.error('Error sending reply:', error);
        setAlert({ type: 'error', message: 'Erro ao enviar resposta' });
      } finally {
        setSending(false);
      }
    };

    const getIcon = (type) => {
      switch(type) {
        case 'appointment': return 'calendar';
        case 'alert': return 'alert-triangle';
        case 'education': return 'book-open';
        case 'reminder': return 'bell';
        case 'message': return 'message-circle';
        default: return 'info';
      }
    };

    const getIconColor = (type) => {
      switch(type) {
        case 'appointment': return 'bg-blue-100 text-blue-600';
        case 'alert': return 'bg-red-100 text-red-600';
        case 'education': return 'bg-purple-100 text-purple-600';
        case 'message': return 'bg-pink-100 text-pink-600';
        default: return 'bg-green-100 text-green-600';
      }
    };

    if (loading) {
      return <div className="text-center py-8">Carregando notificações...</div>;
    }

    return (
      <div className="max-w-4xl mx-auto pb-24 md:pb-0">
        <button onClick={() => window.location.href = 'patient.html'} className="btn-primary mb-4">
          <div className="flex items-center space-x-2">
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar ao Painel</span>
          </div>
        </button>
        <h2 className="text-2xl font-bold mb-6">Notificações</h2>
        
        <div className="space-y-4">
          {notifications.length === 0 ? (
            <div className="bg-white rounded-lg shadow p-8 text-center">
              <div className="icon-bell text-4xl text-gray-300 mb-4"></div>
              <p className="text-gray-500">Nenhuma notificação</p>
            </div>
          ) : (
            notifications.map(notif => (
              <div
                key={notif.objectId}
                className={`bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-md p-6 border border-pink-100 ${
                  !notif.objectData.read ? 'border-l-4 border-[var(--primary-color)]' : ''
                }`}
              >
                <div className="flex items-start space-x-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${getIconColor(notif.objectData.type)}`}>
                    <div className={`icon-${getIcon(notif.objectData.type)} text-xl`}></div>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg text-gray-900">{notif.objectData.title}</h3>
                    <p className="text-sm text-gray-600 mt-2 leading-relaxed">{notif.objectData.message}</p>
                    <p className="text-xs text-gray-400 mt-3">
                      {new Date(notif.createdAt).toLocaleDateString('pt-PT', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric'
                      })}
                    </p>
                    
                    {notif.objectData.type === 'message' && notif.objectData.messageId && (
                      <div className="mt-4">
                        {replyingTo?.objectId === notif.objectId ? (
                          <div className="space-y-3">
                            <textarea
                              value={replyMessage}
                              onChange={(e) => setReplyMessage(e.target.value)}
                              placeholder="Digite sua resposta..."
                              className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent resize-none"
                              rows="3"
                            />
                            <div className="flex gap-2">
                              <button
                                onClick={handleReply}
                                disabled={sending || !replyMessage.trim()}
                                className="btn-primary flex-1 disabled:opacity-50"
                              >
                                {sending ? 'Enviando...' : 'Enviar Resposta'}
                              </button>
                              <button
                                onClick={() => {
                                  setReplyingTo(null);
                                  setReplyMessage('');
                                }}
                                className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                              >
                                Cancelar
                              </button>
                            </div>
                          </div>
                        ) : (
                          <button
                            onClick={() => setReplyingTo(notif)}
                            className="text-sm text-[var(--primary-color)] hover:underline font-medium"
                          >
                            Responder Mensagem
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                  {!notif.objectData.read && (
                    <button
                      onClick={() => markAsRead(notif)}
                      className="text-sm text-[var(--primary-color)] hover:underline font-medium"
                    >
                      Marcar como lida
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('Notifications error:', error);
    return null;
  }
}
function ProfessionalDashboard({ setAlert, onViewChange }) {
  try {
    const [stats, setStats] = React.useState({
      totalPatients: 0,
      highRisk: 0,
      appointments: 0
    });

    React.useEffect(() => {
      loadStats();
    }, []);

    const loadStats = async () => {
      try {
        const user = getCurrentUser();
        if (!user || !user.id) {
          return;
        }
        
        const dbReady = await waitForDatabase();
        if (!dbReady) {
          setStats({ totalPatients: 0, highRisk: 0, appointments: 0 });
          return;
        }
        
        const [patients, assessments, appointments] = await Promise.all([
          retryOperation(async () => await trickleListObjects('user', 100, true)),
          retryOperation(async () => await trickleListObjects('assessment', 100, true)),
          retryOperation(async () => await trickleListObjects('appointment', 100, true))
        ]);
        
        if (!patients || !patients.items || !Array.isArray(patients.items)) {
          setStats({ totalPatients: 0, highRisk: 0, appointments: 0 });
          return;
        }
        
        const myPatients = patients.items.filter(p => 
          p && p.objectData && p.objectData.professionalId === user.id
        );
        
        const highRiskCount = assessments && assessments.items ? 
          assessments.items.filter(a => 
            a && a.objectData && 
            a.objectData.riskLevel === 'high' && 
            myPatients.some(p => p.objectId === a.objectData.patientId)
          ).length : 0;

        const myAppointments = appointments && appointments.items ?
          appointments.items.filter(a => 
            a && a.objectData && a.objectData.professionalId === user.id
          ) : [];

        setStats({
          totalPatients: myPatients.length,
          highRisk: highRiskCount,
          appointments: myAppointments.length
        });
      } catch (error) {
        console.error('Error loading stats:', error);
        setStats({ totalPatients: 0, highRisk: 0, appointments: 0 });
      }
    };

    return (
      <div>
        <div className="bg-gradient-to-br from-[var(--accent-color)] to-white border border-gray-100 rounded-3xl shadow-sm p-8 mb-8">
          <h1 className="text-3xl font-bold text-[var(--text-dark)] mb-3">Bem-vindo ao Maternia</h1>
          <p className="text-sm text-gray-600 leading-relaxed">
            Este painel profissional permite gerir suas pacientes e acompanhar o pré-natal. 
            Utilize as funcionalidades abaixo para gerenciar pacientes, monitorar riscos, 
            agendar consultas e alterar sua senha.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-gradient-to-br from-pink-50 to-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 p-6 border border-pink-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-pink-700 mb-2 uppercase tracking-wide">Minhas Pacientes</p>
                <p className="text-4xl font-bold text-pink-600">{stats.totalPatients}</p>
              </div>
              <div className="w-16 h-16 bg-pink-500 rounded-2xl flex items-center justify-center shadow-lg">
                <div className="icon-users text-2xl text-white"></div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-red-50 to-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 p-6 border border-red-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-red-700 mb-2 uppercase tracking-wide">Alto Risco</p>
                <p className="text-4xl font-bold text-red-600">{stats.highRisk}</p>
              </div>
              <div className="w-16 h-16 bg-red-500 rounded-2xl flex items-center justify-center shadow-lg">
                <div className="icon-alert-triangle text-2xl text-white"></div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <button onClick={() => onViewChange('chat')} className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 animate-slide-in text-left border border-pink-100">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
                <div className="icon-message-circle text-base text-white"></div>
              </div>
              <h3 className="text-lg font-bold text-gray-900">Conversar</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">Comunicar-se com suas pacientes.</p>
          </button>

          <button onClick={() => onViewChange('patients')} className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 animate-slide-in text-left border border-pink-100" style={{ animationDelay: '100ms' }}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-[var(--secondary-color)] rounded-full flex items-center justify-center">
                <div className="icon-users text-base text-white"></div>
              </div>
              <h3 className="text-lg font-bold text-gray-900">Pacientes</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">Gerenciar e cadastrar pacientes.</p>
          </button>

          <button onClick={() => onViewChange('monitoring')} className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 animate-slide-in text-left border border-pink-100" style={{ animationDelay: '200ms' }}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
                <div className="icon-activity text-base text-white"></div>
              </div>
              <h3 className="text-lg font-bold text-gray-900">Monitoramento</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">Monitorar riscos e avaliações.</p>
          </button>

          <button onClick={() => onViewChange('appointments')} className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 animate-slide-in text-left border border-pink-100" style={{ animationDelay: '300ms' }}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-[var(--secondary-color)] rounded-full flex items-center justify-center">
                <div className="icon-calendar text-base text-white"></div>
              </div>
              <h3 className="text-lg font-bold text-gray-900">Consultas</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">Agendar e gerenciar consultas.</p>
          </button>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ProfessionalDashboard error:', error);
    return null;
  }
}

function ProfessionalApp() {
  try {
    const [currentView, setCurrentView] = React.useState('dashboard');
    const [alert, setAlert] = React.useState(null);

    React.useEffect(() => {
      const user = getCurrentUser();
      if (!user) {
        window.location.href = 'login.html';
        return;
      }
      if (user.role !== 'professional') {
        if (user.role === 'admin') {
          window.location.href = 'admin.html';
        } else if (user.role === 'patient') {
          window.location.href = 'patient.html';
        } else {
          window.location.href = 'login.html';
        }
      }
    }, []);

    return (
      <div className="min-h-screen bg-gray-50">
        {alert && <Alert type={alert.type} message={alert.message} onClose={() => setAlert(null)} />}
        <ProfessionalHeader currentView={currentView} onViewChange={setCurrentView} />
        
        <main className="max-w-7xl mx-auto px-4 py-8">
          {currentView === 'dashboard' && <ProfessionalDashboard setAlert={setAlert} onViewChange={setCurrentView} />}
          {currentView === 'patients' && <PatientManagement setAlert={setAlert} onViewChange={setCurrentView} />}
          {currentView === 'monitoring' && <RiskMonitoring setAlert={setAlert} onViewChange={setCurrentView} />}
          {currentView === 'appointments' && <AppointmentManager setAlert={setAlert} onViewChange={setCurrentView} />}
          {currentView === 'reports' && <ProfessionalReports setAlert={setAlert} onViewChange={setCurrentView} />}
          {currentView === 'chat' && <ProfessionalChat setAlert={setAlert} onViewChange={setCurrentView} />}
          {currentView === 'notifications' && <ProfessionalNotifications setAlert={setAlert} onViewChange={setCurrentView} />}
          {currentView === 'password' && <PasswordChange setAlert={setAlert} />}
        </main>
      </div>
    );
  } catch (error) {
    console.error('ProfessionalApp error:', error);
    return null;
  }
}

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Algo deu errado</h1>
            <p className="text-gray-600 mb-4">Pedimos desculpa, mas algo inesperado aconteceu.</p>
            <button onClick={() => window.location.reload()} className="btn-primary">
              Recarregar Página
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <ProfessionalApp />
  </ErrorBoundary>
);

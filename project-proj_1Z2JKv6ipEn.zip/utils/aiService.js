async function callOpenRouterAPI(systemPrompt, userPrompt, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer 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',
          'HTTP-Referer': window.location.origin,
          'X-Title': 'Sistema Pré-Natal'
        },
        body: JSON.stringify({
          model: 'openai/chatgpt-4o-latest',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt }
          ]
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data.choices[0].message.content;
    } catch (error) {
      console.error(`OpenRouter API error (attempt ${i + 1}/${retries}):`, error);
      if (i === retries - 1) {
        return await invokeAIAgent(systemPrompt, userPrompt);
      }
      await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1)));
    }
  }
}

async function assessRisk(symptoms) {
  try {
    const systemPrompt = `Você é um assistente médico especializado em pré-natal. Avalie os sintomas relatados pela gestante e forneça uma análise de risco (baixo, médio ou alto) e recomendações. Responda em JSON com os campos: riskLevel (low/medium/high), analysis, recommendations (array).`;
    
    const userPrompt = `Sintomas relatados: ${JSON.stringify(symptoms)}`;
    
    let response = await callOpenRouterAPI(systemPrompt, userPrompt);
    response = response.replace(/```json/g, '').replace(/```/g, '').trim();
    
    return JSON.parse(response);
  } catch (error) {
    console.error('AI assessment error:', error);
    return {
      riskLevel: 'medium',
      analysis: 'Não foi possível avaliar automaticamente. Consulte seu médico.',
      recommendations: ['Entre em contato com seu profissional de saúde']
    };
  }
}

async function generateEducationalContent(topic, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      if (typeof invokeAIAgent === 'undefined') {
        await new Promise(resolve => setTimeout(resolve, 1000));
        continue;
      }
      
      const systemPrompt = `Você é um educador de saúde pré-natal. Crie conteúdo educativo sobre o tópico solicitado em português de Moçambique. Seja claro, acessível e baseado em evidências.`;
      
      const content = await callOpenRouterAPI(systemPrompt, topic);
      return content;
    } catch (error) {
      console.error(`Content generation error (attempt ${i + 1}/${retries}):`, error);
      if (i === retries - 1) {
        return 'Conteúdo temporariamente indisponível. Por favor, tente novamente em alguns instantes.';
      }
      await new Promise(resolve => setTimeout(resolve, 2000 * (i + 1)));
    }
  }
}

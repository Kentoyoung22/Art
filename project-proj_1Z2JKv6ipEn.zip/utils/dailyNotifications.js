const dailyTopics = [
  "Dicas de cuidado com o estresse durante a gravidez",
  "Importância da hidratação para gestantes",
  "Exercícios de respiração para relaxamento",
  "Cuidados com a alimentação e nutrição",
  "Importância do descanso e sono de qualidade",
  "Exercícios físicos leves e seguros",
  "Preparação emocional para a maternidade",
  "Cuidados com a pele durante a gravidez",
  "Vínculo afetivo com o bebê",
  "Gestão das mudanças hormonais",
  "Cuidados com a postura e movimentos",
  "Importância do apoio familiar",
  "Sinais de alerta que requerem atenção médica",
  "Benefícios da meditação e mindfulness",
  "Preparação para o parto",
  "Cuidados com a saúde bucal"
];

async function generateUniqueDailyTip() {
  try {
    const randomTopic = dailyTopics[Math.floor(Math.random() * dailyTopics.length)];
    
    const systemPrompt = `Você é um especialista em saúde pré-natal em Moçambique. Crie uma dica diária curta e prática para gestantes.
    
Formato obrigatório (responda APENAS em JSON sem markdown):
{
  "title": "Título atraente e motivador (máximo 60 caracteres)",
  "message": "Mensagem prática e acolhedora (150-200 caracteres)"
}

Regras importantes:
- Use tom caloroso, amigável e encorajador
- Seja específica e prática
- Adapte ao contexto de Moçambique
- Não repita informações básicas já conhecidas
- Cada dica deve ser única e interessante`;

    const userPrompt = `Tópico de hoje: ${randomTopic}

Crie uma dica COMPLETAMENTE NOVA sobre este tema, diferente de qualquer dica anterior. Seja criativa e surpreendente.`;

    let response;
    if (typeof invokeAIAgent !== 'undefined') {
      response = await invokeAIAgent(systemPrompt, userPrompt);
    } else {
      return {
        title: "Cuide de Você Hoje",
        message: "Lembre-se de reservar um momento para relaxar e cuidar de si mesma. Sua saúde mental é importante!"
      };
    }
    
    response = response.replace(/```json/g, '').replace(/```/g, '').trim();
    const tip = JSON.parse(response);
    
    return tip;
  } catch (error) {
    console.error('Error generating daily tip:', error);
    return {
      title: "Cuide-se Hoje",
      message: "Reserve um tempo para você e seu bebê. Hidrate-se bem e descanse sempre que possível."
    };
  }
}

async function sendDailyNotification(patientId) {
  try {
    const today = new Date().toISOString().split('T')[0];
    const notificationKey = `lastNotification_${patientId}`;
    const lastNotification = localStorage.getItem(notificationKey);
    
    if (lastNotification === today) {
      return;
    }
    
    const dailyTip = await generateUniqueDailyTip();
    
    await trickleCreateObject('notification', {
      userId: patientId,
      title: dailyTip.title,
      message: dailyTip.message,
      type: 'education',
      read: false,
      createdAt: new Date().toISOString()
    });
    
    localStorage.setItem(notificationKey, today);
    console.log('Daily notification sent successfully');
  } catch (error) {
    console.error('Error sending daily notification:', error);
  }
}

async function initDailyNotifications() {
  const user = getCurrentUser();
  if (user && user.role === 'patient') {
    await sendDailyNotification(user.id);
    
    setInterval(() => {
      sendDailyNotification(user.id);
    }, 3600000);
  }
}
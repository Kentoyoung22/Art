async function waitForDatabase() {
  let attempts = 0;
  const maxAttempts = 40;
  
  const checkDatabase = () => {
    return new Promise((resolve) => {
      const check = () => {
        attempts++;
        
        if (typeof trickleListObjects !== 'undefined' && 
            typeof trickleCreateObject !== 'undefined' &&
            typeof trickleUpdateObject !== 'undefined' &&
            typeof trickleGetObject !== 'undefined' &&
            typeof trickleDeleteObject !== 'undefined') {
          setTimeout(() => resolve(true), 1000);
        } else if (attempts < maxAttempts) {
          setTimeout(check, 500);
        } else {
          resolve(false);
        }
      };
      check();
    });
  };
  
  return await checkDatabase();
}

async function retryOperation(operation, maxRetries = 5) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      if (typeof trickleListObjects === 'undefined') {
        await new Promise(resolve => setTimeout(resolve, 1000));
        continue;
      }
      return await operation();
    } catch (error) {
      console.error(`Retry attempt ${i + 1} failed:`, error);
      if (i === maxRetries - 1) throw error;
      const delay = Math.min(2000 * (i + 1), 8000);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
}

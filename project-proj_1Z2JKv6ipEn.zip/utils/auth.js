async function login(email, password) {
  try {
    if (typeof trickleListObjects === 'undefined') {
      throw new Error('Database not ready');
    }
    
    const users = await trickleListObjects('user', 100, true);
    
    if (!users?.items) {
      return { success: false, message: 'Erro ao acessar dados' };
    }

    const user = users.items.find(u => 
      u.objectData?.email === email && u.objectData?.password === password
    );

    if (!user) {
      return { success: false, message: 'Email ou senha incorretos' };
    }

    if (user.objectData.active === false) {
      return { success: false, message: 'Usuário desativado' };
    }

    localStorage.setItem('currentUser', JSON.stringify({
      id: user.objectId,
      name: user.objectData.name,
      email: user.objectData.email,
      role: user.objectData.role
    }));

    try {
      await trickleCreateObject('system_log', {
        userId: user.objectId,
        userName: user.objectData.name,
        userRole: user.objectData.role,
        action: 'login',
        description: `${user.objectData.name} fez login`,
        timestamp: new Date().toISOString()
      });
    } catch (e) {
      console.error('Log error:', e);
    }

    return { success: true, role: user.objectData.role };
  } catch (error) {
    console.error('Login error:', error);
    return { success: false, message: 'Erro de conexão. Aguarde alguns instantes e tente novamente.' };
  }
}

async function logout() {
  const user = getCurrentUser();
  
  if (user && typeof trickleCreateObject !== 'undefined') {
    try {
      await trickleCreateObject('system_log', {
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'logout',
        description: `${user.name} saiu do sistema`,
        ipAddress: 'N/A',
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Logout log error:', error);
    }
  }
  
  localStorage.removeItem('currentUser');
  window.location.href = 'login.html';
}

function getCurrentUser() {
  const user = localStorage.getItem('currentUser');
  return user ? JSON.parse(user) : null;
}
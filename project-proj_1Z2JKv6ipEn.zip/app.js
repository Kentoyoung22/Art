function LandingPage() {
  try {
    return (
      <div className="min-h-screen bg-white">
        <header className="absolute top-0 left-0 right-0 z-50 bg-transparent">
          <div className="max-w-7xl mx-auto px-6 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
                  <div className="icon-heart text-2xl text-white"></div>
                </div>
                <span className="text-2xl font-bold text-[var(--text-dark)]">Maternia</span>
              </div>
              <a href="login.html" className="px-8 py-3 bg-[var(--primary-color)] text-white rounded-full font-medium hover:opacity-90 transition-opacity">
                Entrar
              </a>
            </div>
          </div>
        </header>

        <section className="relative pt-32 pb-20 px-6 bg-gradient-to-br from-[#FFF5F7] to-white overflow-hidden">
          <div className="max-w-7xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-8">
                <div className="inline-block px-4 py-2 bg-white rounded-full shadow-sm">
                  <span className="text-[var(--primary-color)] font-medium text-sm">Hospital Central de Nampula</span>
                </div>
                <h1 className="text-5xl lg:text-6xl font-bold text-[var(--text-dark)] leading-tight">
                  Cuidado Pré-Natal
                  <span className="block text-[var(--primary-color)]">Inteligente</span>
                </h1>
                <p className="text-xl text-[var(--text-light)] leading-relaxed">
                  Estamos empenhados em apoiá-lo com cuidados compassivos e orientação especializada enquanto navega pela bela jornada da gravidez.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <a href="login.html" className="px-8 py-4 bg-[var(--primary-color)] text-white rounded-full font-medium text-center hover:opacity-90 transition-opacity">
                    Começar Agora
                  </a>
                  <a href="#features" className="px-8 py-4 bg-white border-2 border-gray-200 text-[var(--text-dark)] rounded-full font-medium text-center hover:border-[var(--primary-color)] transition-colors">
                    Saiba Mais
                  </a>
                </div>
              </div>
              <div className="relative">
                <img 
                  src="https://app.trickle.so/storage/public/images/usr_16c969a760000001/3edbfb9c-1ce9-4a33-830d-7a5cf3d03a4e.png?w=1000&h=667"
                  alt="Profissional de saúde com paciente grávida"
                  className="w-full h-96 object-cover rounded-3xl shadow-2xl"
                />
              </div>
            </div>
          </div>
        </section>

        <section id="features" className="py-20 px-6 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <span className="text-[var(--primary-color)] font-semibold text-sm uppercase tracking-wide">Funcionalidades</span>
              <h2 className="text-4xl font-bold text-[var(--text-dark)] mt-4">Como Podemos Ajudar</h2>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              <div className="p-8 bg-white rounded-2xl border border-gray-100 hover:shadow-xl transition-shadow">
                <div className="w-16 h-16 bg-[#FFE5EC] rounded-2xl flex items-center justify-center mb-6">
                  <div className="icon-heart-pulse text-3xl text-[var(--primary-color)]"></div>
                </div>
                <h3 className="text-xl font-bold text-[var(--text-dark)] mb-3">Para Gestantes</h3>
                <p className="text-[var(--text-light)] leading-relaxed">
                  Acompanhe sua gravidez, receba orientações personalizadas e mantenha contato direto com seu profissional de saúde
                </p>
              </div>

              <div className="p-8 bg-white rounded-2xl border border-gray-100 hover:shadow-xl transition-shadow">
                <div className="w-16 h-16 bg-[#E5F0FF] rounded-2xl flex items-center justify-center mb-6">
                  <div className="icon-user-check text-3xl text-[var(--secondary-color)]"></div>
                </div>
                <h3 className="text-xl font-bold text-[var(--text-dark)] mb-3">Para Profissionais</h3>
                <p className="text-[var(--text-light)] leading-relaxed">
                  Gerencie pacientes, monitore riscos e organize consultas de forma eficiente e integrada
                </p>
              </div>

              <div className="p-8 bg-white rounded-2xl border border-gray-100 hover:shadow-xl transition-shadow">
                <div className="w-16 h-16 bg-[#F0E5FF] rounded-2xl flex items-center justify-center mb-6">
                  <div className="icon-shield text-3xl text-purple-600"></div>
                </div>
                <h3 className="text-xl font-bold text-[var(--text-dark)] mb-3">Seguro e Confiável</h3>
                <p className="text-[var(--text-light)] leading-relaxed">
                  Sistema seguro com backup automático e proteção total dos seus dados médicos
                </p>
              </div>
            </div>
          </div>
        </section>

        <footer className="py-12 px-6 bg-[#3B2F2F]">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <div>
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
                    <div className="icon-heart text-xl text-white"></div>
                  </div>
                  <span className="text-xl font-bold text-white">Maternia</span>
                </div>
                <p className="text-gray-400 text-sm mb-4">
                  No Maternia, priorizamos a saúde e felicidade das nossas pacientes acima de tudo.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4 text-white">Contacto</h3>
                <ul className="space-y-3">
                  <li className="flex items-start space-x-2">
                    <div className="icon-map-pin text-lg text-[var(--primary-color)] mt-1"></div>
                    <span className="text-gray-400 text-sm">Rua Dar es Salaam, Nampula, Moçambique</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <div className="icon-mail text-lg text-[var(--primary-color)]"></div>
                    <a href="mailto:suporte@maternia.mz" className="text-gray-400 hover:text-white transition-colors text-sm">suporte@maternia.mz</a>
                  </li>
                  <li className="flex items-center space-x-2">
                    <div className="icon-phone text-lg text-[var(--primary-color)]"></div>
                    <a href="tel:+25826216681" className="text-gray-400 hover:text-white transition-colors text-sm">+258 26 216 681</a>
                  </li>
                  <li className="flex items-center space-x-2">
                    <div className="icon-clock text-lg text-[var(--primary-color)]"></div>
                    <span className="text-gray-400 text-sm">Aberto 24h/dia, 7 dias/semana</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="border-t border-gray-700 pt-6">
              <p className="text-gray-400 text-sm text-center">© 2025 Hospital Central de Nampula. Todos os direitos reservados.</p>
            </div>
          </div>
        </footer>
      </div>
    );
  } catch (error) {
    console.error('LandingPage error:', error);
    return null;
  }
}

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js')
      .then(registration => console.log('SW registered:', registration))
      .catch(error => console.log('SW registration failed:', error));
  });
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<LandingPage />);

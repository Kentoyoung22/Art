function PatientApp() {
  try {
    const [currentView, setCurrentView] = React.useState('dashboard');
    const [alert, setAlert] = React.useState(null);

    React.useEffect(() => {
      const user = getCurrentUser();
      if (!user) {
        window.location.href = 'login.html';
        return;
      }
      if (user.role !== 'patient') {
        if (user.role === 'admin') {
          window.location.href = 'admin.html';
        } else if (user.role === 'professional') {
          window.location.href = 'professional.html';
        } else {
          window.location.href = 'login.html';
        }
        return;
      }
      
      const hash = window.location.hash.substring(1);
      if (hash === 'chat') {
        setCurrentView('chat');
        window.location.hash = '';
      }
      
      const handleViewChange = (e) => {
        if (e.detail) {
          setCurrentView(e.detail);
        }
      };
      
      window.addEventListener('changeView', handleViewChange);
      initDailyNotifications();
      
      return () => {
        window.removeEventListener('changeView', handleViewChange);
      };
    }, []);

    return (
      <div className="min-h-screen bg-gray-50">
        {alert && <Alert type={alert.type} message={alert.message} onClose={() => setAlert(null)} />}
        <PatientHeader currentView={currentView} onViewChange={setCurrentView} />
        
        <main className="max-w-7xl mx-auto px-4 py-8">
          {currentView === 'dashboard' && <Dashboard setAlert={setAlert} onViewChange={setCurrentView} />}
          {currentView === 'assessment' && <SelfAssessment setAlert={setAlert} />}
          {currentView === 'appointments' && <AppointmentList setAlert={setAlert} />}
          {currentView === 'notifications' && <Notifications setAlert={setAlert} />}
          {currentView === 'education' && <EducationalContent setAlert={setAlert} />}
          {currentView === 'chat' && <ChatWithProfessional setAlert={setAlert} />}
          {currentView === 'password' && <PasswordChange setAlert={setAlert} />}
        </main>
      </div>
    );
  } catch (error) {
    console.error('PatientApp error:', error);
    return null;
  }
}

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Algo deu errado</h1>
            <p className="text-gray-600 mb-4">Pedimos desculpa, mas algo inesperado aconteceu.</p>
            <button onClick={() => window.location.reload()} className="btn-primary">
              Recarregar Página
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <PatientApp />
  </ErrorBoundary>
);

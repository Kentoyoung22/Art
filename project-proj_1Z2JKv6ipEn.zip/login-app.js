function LoginApp() {
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [alert, setAlert] = React.useState(null);
  const [ready, setReady] = React.useState(false);

  React.useEffect(() => {
    initializeDatabase();
  }, []);

  const initializeDatabase = async () => {
    try {
      const dbReady = await waitForDatabase();
      
      if (!dbReady) {
        console.error('Database connection timeout');
        setAlert({ 
          type: 'error', 
          message: 'Não foi possível conectar ao banco de dados. Por favor, aguarde 30 segundos e recarregue a página.' 
        });
        setReady(true);
        return;
      }
      
      await retryOperation(async () => {
        const users = await trickleListObjects('user', 10, true);
        if (!users.items.some(u => u.objectData?.role === 'admin')) {
          await trickleCreateObject('user', {
            name: 'Administrador',
            email: 'admin@gmail.com',
            password: 'Natal2025!',
            role: 'admin',
            active: true
          });
        }
      }, 12);
      
      setReady(true);
    } catch (error) {
      console.error('Database initialization error:', error);
      setAlert({ 
        type: 'error', 
        message: 'Erro ao inicializar. Aguarde 30 segundos e recarregue a página, ou tente novamente mais tarde.' 
      });
      setReady(true);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setAlert(null);
    
    try {
      if (typeof trickleListObjects === 'undefined') {
        throw new Error('Database not ready');
      }

      const result = await retryOperation(async () => {
        return await login(email, password);
      }, 12);
      
      if (result.success) {
        setAlert({ type: 'success', message: 'Login realizado com sucesso!' });
        setTimeout(() => {
          if (result.role === 'admin') window.location.href = 'admin.html';
          else if (result.role === 'professional') window.location.href = 'professional.html';
          else if (result.role === 'patient') window.location.href = 'patient.html';
        }, 1000);
      } else {
        setAlert({ type: 'error', message: result.message });
      }
    } catch (error) {
      console.error('Login error:', error);
      setAlert({ 
        type: 'error', 
        message: 'Erro ao conectar com o servidor. Aguarde 30 segundos e tente novamente, ou recarregue a página.' 
      });
    } finally {
      setLoading(false);
    }
  };

  if (!ready) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF5F7] to-white flex items-center justify-center p-4">
      {alert && <Alert type={alert.type} message={alert.message} onClose={() => setAlert(null)} />}
      
      <a href="index.html" className="absolute top-6 left-6 flex items-center gap-2 text-[var(--text-dark)] hover:text-[var(--primary-color)] transition-colors">
        <div className="icon-arrow-left text-xl"></div>
        <span className="font-medium">Voltar</span>
      </a>

      <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl p-10">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-[var(--primary-color)] rounded-full flex items-center justify-center mx-auto mb-6">
            <div className="icon-heart text-4xl text-white"></div>
          </div>
          <h1 className="text-3xl font-bold text-[var(--text-dark)] mb-2">Bem-vindo</h1>
          <p className="text-gray-600">Entre para acessar o sistema</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-6 py-4 border-2 border-gray-200 rounded-2xl focus:outline-none focus:border-[var(--primary-color)] transition-colors"
              placeholder="seu@email.com"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Senha</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-6 py-4 border-2 border-gray-200 rounded-2xl focus:outline-none focus:border-[var(--primary-color)] transition-colors"
              placeholder="••••••••"
              required
            />
          </div>

          <button 
            type="submit" 
            className="w-full px-6 py-4 bg-[var(--primary-color)] text-white rounded-full font-medium hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed" 
            disabled={loading}
          >
            {loading ? 'Entrando...' : 'Entrar'}
          </button>
        </form>


      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<LoginApp />);
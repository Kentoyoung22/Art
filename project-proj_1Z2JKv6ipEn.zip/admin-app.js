function AdminDashboard({ setAlert, onViewChange }) {
  try {
    const [stats, setStats] = React.useState({
      activeUsers: 0,
      totalProfessionals: 0,
      totalPatients: 0
    });

    React.useEffect(() => {
      loadStats();
    }, []);

    const loadStats = async () => {
      try {
        const dbReady = await waitForDatabase();
        if (!dbReady) {
          setStats({ activeUsers: 0, totalProfessionals: 0, totalPatients: 0 });
          return;
        }
        
        const users = await retryOperation(async () => {
          return await trickleListObjects('user', 1000, true);
        });
        
        if (users && users.items) {
          setStats({
            activeUsers: users.items.filter(u => u.objectData.active !== false).length,
            totalProfessionals: users.items.filter(u => u.objectData.role === 'professional').length,
            totalPatients: users.items.filter(u => u.objectData.role === 'patient').length
          });
        }
      } catch (error) {
        console.error('Error loading stats:', error);
        setStats({ activeUsers: 0, totalProfessionals: 0, totalPatients: 0 });
      }
    };

    return (
      <div>
        <div className="bg-gradient-to-br from-[var(--accent-color)] to-white border border-gray-100 rounded-3xl shadow-sm p-8 mb-8">
          <h1 className="text-3xl font-bold text-[var(--text-dark)] mb-3">Bem-vindo ao Maternia</h1>
          <p className="text-sm text-gray-600 leading-relaxed">
            Este painel administrativo permite gerir todo o sistema de acompanhamento pré-natal. 
            Utilize as funcionalidades abaixo para administrar usuários, monitorar atividades, 
            realizar backups e gerar relatórios detalhados do sistema.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-gradient-to-br from-pink-50 to-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 p-6 border border-pink-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-pink-700 mb-2 uppercase tracking-wide">Usuários Ativos</p>
                <p className="text-4xl font-bold text-pink-600">{stats.activeUsers}</p>
              </div>
              <div className="w-16 h-16 bg-pink-500 rounded-2xl flex items-center justify-center shadow-lg">
                <div className="icon-users text-2xl text-white"></div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-rose-50 to-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 p-6 border border-rose-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-rose-700 mb-2 uppercase tracking-wide">Profissionais</p>
                <p className="text-4xl font-bold text-rose-600">{stats.totalProfessionals}</p>
              </div>
              <div className="w-16 h-16 bg-rose-500 rounded-2xl flex items-center justify-center shadow-lg">
                <div className="icon-user-check text-2xl text-white"></div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-pink-50 to-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 p-6 border border-pink-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-pink-700 mb-2 uppercase tracking-wide">Pacientes</p>
                <p className="text-4xl font-bold text-pink-600">{stats.totalPatients}</p>
              </div>
              <div className="w-16 h-16 bg-pink-500 rounded-2xl flex items-center justify-center shadow-lg">
                <div className="icon-heart text-2xl text-white"></div>
              </div>
            </div>
          </div>
        </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <button onClick={() => onViewChange('users')} className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 animate-slide-in text-left border border-pink-100">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
                <div className="icon-users text-base text-white"></div>
              </div>
              <h3 className="text-lg font-bold text-gray-900">Gerenciar Usuários</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">Administrar usuários e permissões do sistema.</p>
          </button>

          <button onClick={() => onViewChange('logs')} className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 animate-slide-in text-left border border-pink-100" style={{ animationDelay: '100ms' }}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-[var(--secondary-color)] rounded-full flex items-center justify-center">
                <div className="icon-activity text-base text-white"></div>
              </div>
              <h3 className="text-lg font-bold text-gray-900">Logs de Acesso</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">Auditar logs de acesso e atividades.</p>
          </button>

          <button onClick={() => onViewChange('reports')} className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 animate-slide-in text-left border border-pink-100" style={{ animationDelay: '200ms' }}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
                <div className="icon-chart-bar text-base text-white"></div>
              </div>
              <h3 className="text-lg font-bold text-gray-900">Relatórios</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">Visualizar estatísticas e relatórios detalhados.</p>
          </button>

          <button onClick={() => onViewChange('backup')} className="bg-gradient-to-br from-[var(--accent-color)] to-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 animate-slide-in text-left border border-pink-100" style={{ animationDelay: '300ms' }}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-[var(--secondary-color)] rounded-full flex items-center justify-center">
                <div className="icon-database text-base text-white"></div>
              </div>
              <h3 className="text-lg font-bold text-gray-900">Backup Automatizado</h3>
            </div>
            <p className="text-gray-600 leading-relaxed">Sistema completo de backup com agendamento automático e recuperação segura.</p>
          </button>
        </div>
      </div>
    );
  } catch (error) {
    console.error('AdminDashboard error:', error);
    return null;
  }
}

function AdminApp() {
  try {
    const [currentView, setCurrentView] = React.useState('dashboard');
    const [alert, setAlert] = React.useState(null);

    React.useEffect(() => {
      const user = getCurrentUser();
      if (!user) {
        window.location.href = 'login.html';
        return;
      }
      if (user.role !== 'admin') {
        if (user.role === 'professional') {
          window.location.href = 'professional.html';
        } else if (user.role === 'patient') {
          window.location.href = 'patient.html';
        } else {
          window.location.href = 'login.html';
        }
      }
    }, []);

    return (
      <div className="min-h-screen bg-gray-50">
        {alert && <Alert type={alert.type} message={alert.message} onClose={() => setAlert(null)} />}
        <AdminHeader currentView={currentView} onViewChange={setCurrentView} />
        
        <main className="max-w-7xl mx-auto px-4 py-8">
          {currentView === 'dashboard' && <AdminDashboard setAlert={setAlert} onViewChange={setCurrentView} />}
          {currentView === 'users' && <UserManagement setAlert={setAlert} onViewChange={setCurrentView} />}
          {currentView === 'logs' && <SystemLogs setAlert={setAlert} onViewChange={setCurrentView} />}
          {currentView === 'reports' && <AdminReports setAlert={setAlert} onViewChange={setCurrentView} />}
          {currentView === 'backup' && <BackupManager setAlert={setAlert} onViewChange={setCurrentView} />}
          {currentView === 'password' && <PasswordChange setAlert={setAlert} />}
        </main>
      </div>
    );
  } catch (error) {
    console.error('AdminApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<AdminApp />);